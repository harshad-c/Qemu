module("cloud_req.cloud_account", package.seeall)

local cloud = require "cloud_req.cloud_comm"
local json  = require "luci.json"
local sys   = require "luci.sys"
local uci   = require "luci.model.uci"
local dbg   = require "luci.tools.debug"
local accmgnt   = require "luci.model.accountmgnt"
local nixio = require "nixio"
local fs    = require "luci.fs"
local uci_r = uci.cursor()
local CLOUD_TMP_DIR = "/tmp/cloud/"
local LOGIN_STATUS = CLOUD_TMP_DIR .. "login_status"

function bind_device(cloudUserName, cloudPassword)
	local req = {}
	req.params = {}

	req.method = "bindDevice"
	req.params.deviceId = cloud.TrimStr(sys.exec("getfirm DEV_ID"))
	req.params.cloudUserName = cloudUserName
	req.params.cloudPassword = cloudPassword

	local re, data = cloud.send_request_sync(req, 5000, 1)

	-- connection error
	if re ~= 0 then return re end

	if data.error_code == 0 then 
		local accid
		if data.result and data.result.accountId then
			accid = data.result.accountId
		end 
		uci_r:set("cloud_config", "device_status", "bind_status", "1")
		uci_r:set("cloud_config", "device_status", "need_unbind", "0")
		sys.call("touch /tmp/ifttt_allow_upload &")
		accmgnt.set_cloudAccount(cloudUserName, cloudPassword, accid)
		uci_r:commit("cloud_config")

		--change the cloud service
		if fs.isfile("/usr/sbin/cloud_changeService") then
			dofile("/usr/sbin/cloud_changeService")
		end
	end
	return data.error_code
end

function unbind_device(cloudUserName)
	local req = {}
	req.params = {}

	req.params.deviceId = cloud.TrimStr(sys.exec("getfirm DEV_ID"))
	
	local users = accmgnt.get_cloudAccount()
	local user = nil
	if users and #users ~= 0 then
		user = type(users) == "table" and users[1] or users
	end
	if user and user.accountid then
		--prior to use new method "unbindDeviceWithAccountId"
		req.method = "unbindDeviceWithAccountId"
		req.params.accountId = user.accountid
	else
		--need to be compatible with no accountid
		req.method = "unbindDevice"
		if cloudUserName and cloudUserName ~= "" then
			req.params.cloudUserName = cloudUserName
		else
			if not user or not user.username then
				return false
			end
			req.params.cloudUserName = user.username
 		end
	end

	local re, data = cloud.send_request_sync(req, 5000, 1)

	-- connection error
	if re ~= 0 then return re end

	if data.error_code == 0 then
		uci_r:set("cloud_config", "device_status", "bind_status", "0")
		uci_r:set("cloud_config", "device_status", "need_unbind", "0")
		sys.call("rm -rf /tmp/ifttt_allow_upload")
		uci_r:commit("cloud_config")
		uci_r:delete_all("accountmgnt", "cloud_account")
		uci_r:commit("accountmgnt")	
		sys.call("echo 0 > %s" % {LOGIN_STATUS})

		--change the cloud service
		if fs.isfile("/usr/sbin/cloud_changeService") then
			dofile("/usr/sbin/cloud_changeService")
		end
	end
	return data.error_code
end

function account_login(cloudUserName, cloudPassword)
	local req = {}
	req.params = {}

	req.method = "deviceAccountLogin"
	req.params.deviceId = cloud.TrimStr(sys.exec("getfirm DEV_ID"))
	req.params.cloudUserName = cloudUserName
	req.params.cloudPassword = cloudPassword

	local re, data = cloud.send_request_sync(req, 5000, 1)

	-- connection error
	if re ~= 0 then return re end
	
	if data.error_code == 0 then
		if not nixio.fs.access(CLOUD_TMP_DIR) then
			sys.call("mkdir -p %s" % {CLOUD_TMP_DIR})
		end
		sys.call("echo 1 > %s" % {LOGIN_STATUS})
		uci_r:set("cloud_config", "login", "username", cloudUserName)
		uci_r:set("cloud_config", "login", "role", data.result.role)
		local user = accmgnt.get_cloudAccountByName(cloudUserName)
		if not user then
			local users = accmgnt.get_cloudAccount()
			if users and #users ~= 0 then
				user = type(users) == "table" and users[1] or users
			end
		end
		if data.result.role == 0 and user and cloudPassword ~= user.password then
			if cloudPassword ~= user.password or cloudUserName ~= user.username then
				accmgnt.set_cloudAccount(cloudUserName, cloudPassword, user.accountid)
			end
 		end
		uci_r:commit("cloud_config")	
	end

	return data.error_code
end

function get_accountInfo(cloudUserName)
	local req = {}
	req.params = {}

	req.method = "getAccountInfo"
	req.params.cloudUserName = cloudUserName

	local re, data = cloud.send_request_sync(req, 5000, 1)

	-- connection error
	if re ~= 0 then return re end

	if data.error_code == 0 then
		uci_r:set("cloud_config", "login", "nickname", data.result.nickname)
		uci_r:set("cloud_config", "login", "regTime", data.result.regTime)
		uci_r:set("cloud_config", "login", "username", data.result.email)
		uci_r:commit("cloud_config")	
	end
	return data.error_code
end

function update_alias(alias)
	local req = {}
	req.params = {}

	req.method = "updateAlias"
	req.params.alias = alias
	req.params.deviceId = cloud.TrimStr(sys.exec("getfirm DEV_ID"))

	local re, data = cloud.send_request_sync(req, 5000, 1)

	-- connection error
	if re ~= 0 then return re end
	if data.error_code == 0 then
		uci_r:set("cloud_config", "info", "alias", alias)
		uci_r:set("cloud_config", "info", "alias_changed", "true")
		uci_r:commit("cloud_config")	
	end

	return data.error_code
end

function remove_deviceUser(ownerAccount, userAccount)
	local req = {}
	req.params = {}

	req.method = "removeDeviceUser"
	req.params.ownerAccount = ownerAccount
	req.params.userAccount = userAccount
	req.params.deviceId = cloud.TrimStr(sys.exec("getfirm DEV_ID"))

	local re, data = cloud.send_request_sync(req, 5000, 1)

	-- connection error
	if re ~= 0 then return re end

	return data.error_code
end
