--[[
Copyright(c) 2008-2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  status.lua
Details :  Controller for status webpage
Author  :  Ye Qianchuan <yeqianchuan@tp-link.net>
Version :  1.0.0
Date    :  05 Mar, 2014
]]--

module("luci.controller.admin.status", package.seeall)

local util  = require "luci.util"
local ubus  = require "ubus"
local ctl   = require "luci.model.controller"
local dbg   = require "luci.tools.debug"
local uci   = require "luci.model.uci"
local uci_r = uci.cursor()
local wlan  = require "luci.model.wireless"

local _ubus

local controller_url = "luci.controller.admin"
local ext_webmobile_dispatch_tbl = {
    network = {
        controller = controller_url .. ".network",
        target = "dispatch",
        forms = {"status_all"}
    },
    wireless = {
        controller = controller_url .. ".wireless",
        target = "wireless_dispatch",
        -- forms = {"wireless_2g", "wireless_5g", "guest_2g", "guest_5g", "guest"}
        forms = {"status_all"}
    },
    usb = {
        controller = controller_url .. ".usbshare",
        target = "usbshare_dispatch",
        forms = {"disk_webmobile_status", "printer_status"},
    },
    status = {
        controller = controller_url .. ".status",
        target = "dispatch",
        forms = {"perf", "access_devices_wired", "access_devices_wireless_host", "access_devices_wireless_guest"}
    },
	modem = {
		controller = controller_url .. ".usbmodem",
        target = "dispatch",
        forms = {"mobile_inf"}
	}
}

function get_webmobile_all(http_form)
    local data = {}
    local success = true
    http_form = {operation = "read"}
    for mod, dsp in pairs(ext_webmobile_dispatch_tbl) do
        local target = dsp.controller and require(dsp.controller)[dsp.target]
        http_form["form"] = dsp.forms
        local ret = target(http_form)
        if ret.success then
            assert(#ret.data == 0)
            util.update(data, ret.data)
        else
            success = false
        end
    end

    return success and data
end
local ext_dispatch_tbl = {
    network = {
        controller = controller_url .. ".network",
        target = "dispatch",
        forms = {"status_all"}
    },
    wireless = {
        controller = controller_url .. ".wireless",
        target = "wireless_dispatch",
        -- forms = {"wireless_2g", "wireless_5g", "guest_2g", "guest_5g", "guest"}
        forms = {"status_all"}
    },
    usb = {
        controller = controller_url .. ".usbshare",
        target = "usbshare_dispatch",
        forms = {"disk_status", "printer_status"},
    },
    status = {
        controller = controller_url .. ".status",
        target = "dispatch",
        forms = {"perf", "access_devices_wired", "access_devices_wireless_host", "access_devices_wireless_guest"}
    },
	modem = {
		controller = controller_url .. ".usbmodem",
        target = "dispatch",
        forms = {"mobile_inf"}
	}
}

function get_all(http_form)
    local data = {}
    local success = true
    http_form = {operation = "read"}
    for mod, dsp in pairs(ext_dispatch_tbl) do
        local target = dsp.controller and require(dsp.controller)[dsp.target]
        http_form["form"] = dsp.forms
        local ret = target(http_form)
        if ret.success then
            assert(#ret.data == 0)
            util.update(data, ret.data)
        else
            success = false
        end
    end
	
    return success and data
end

local function read_meminfo()
    local meminfo = {}
    local file = io.open("/proc/meminfo")
    local buf = file:read("*a")
    file:close()

    meminfo.total = tonumber(buf:match("MemTotal:%s*(%d+)"))
    meminfo.free = tonumber(buf:match("MemFree:%s*(%d+)"))
    meminfo.buffers = tonumber(buf:match("Buffers:%s*(%d+)"))
    meminfo.cached = tonumber(buf:match("\nCached:%s*(%d+)"))
    meminfo.swapcached = tonumber(buf:match("SwapCached:%s*(%d+)"))

    meminfo.used = meminfo.total - meminfo.free - meminfo.buffers - meminfo.cached - meminfo.swapcached
    meminfo.used = meminfo.used > 0 and meminfo.used or 0
    return meminfo
end

local function read_cpuinfo()
    local cpuinfo = {}
    local file = io.open("/proc/stat")
    local buf = file:read("*l")
    file:close()

    for stat in buf:gmatch("%d+") do
        cpuinfo[#cpuinfo + 1] = tonumber(stat)
    end
    cpuinfo.total = 0
    for _, stat in ipairs(cpuinfo) do
        cpuinfo.total = cpuinfo.total + stat
    end
    cpuinfo.idle = cpuinfo[4] or 0
    cpuinfo.iowait = cpuinfo[5] or 0
    cpuinfo.busy = cpuinfo.total - cpuinfo.idle - cpuinfo.iowait
    cpuinfo.busy = cpuinfo.busy > 0 and cpuinfo.busy or 0
    return cpuinfo
end

function get_perf_fallback(http_form)
    -- Memory usage
    local meminfo = read_meminfo()
    local mem_usage = math.floor(100 * meminfo.used / meminfo.total) / 100

    -- CPU usage
    local nixio = require("nixio")

    local cpuinfo_prev = read_cpuinfo()
    -- Wait 100ms
    nixio.nanosleep(0, 100000000)
    local cpuinfo_cur = read_cpuinfo()

    local total = cpuinfo_cur.total - cpuinfo_prev.total
    total = total > 0 and total or 1

    local busy = cpuinfo_cur.busy - cpuinfo_prev.busy
    busy = busy > 0 and busy or 0

    local cpu_usage = math.floor(100 * busy / total) / 100

    local data = {
        cpu_usage = cpu_usage,
        mem_usage = mem_usage
    }
    return data
end

function get_perf(http_form)
    if not _ubus then
        _ubus = ubus.connect()
    end

    if _ubus then
        local data = _ubus:call("system_perf", "status", {})
        if data then
            return {
                cpu_usage = data.cpu_usage / 100,
                mem_usage = data.mem_usage / 100
            }
        end
    end

    -- The following code might cause problem
    -- if this function is called multiple times quickly.
    local fs = require "nixio.fs"
    if fs.access("/etc/init.d/system-monitor", "x") and luci.sys.fork_call("pgrep sysmond") == 1 then
        local sys = require "luci.sys"
        sys.fork_exec("/etc/init.d/system-monitor restart")
    end
    return get_perf_fallback(http_form)
end

function get_access_devices(http_form, wire_type)
    local data = {}
    local clist = require("luci.model.client_mgmt").get_client_list() or {}
    local wire_types = wire_type == "wired" and {"wired"} or {"2.4G", "5G"}
    local guest = wire_type == "guest" and "GUEST" or "NON_GUEST"
    local ap = wlan.Apcfg()
    local sta_list = (ap and ap:assoclist()) or {}
	local wds1=uci_r:get("wireless", "ath02", "enable")
	local wds2=uci_r:get("wireless", "ath12", "enable")

    for _, client in ipairs(clist) do
        if util.contains(wire_types, client.wire_type) and client.guest ==  guest then
			if wds1 == "on" or wds2 == "on" then
				local found = false

				if wire_type == "wired" then
					found = true
				else
					for _, sta in ipairs(sta_list) do
						if sta.mac == client.mac then
							found = true
							break;
						end
					end
				end

				if found then
					data[#data + 1] = {
						hostname = client.hostname,
						ipaddr = client.ip,
						macaddr = client.mac,
						wire_type = client.wire_type
					}
				end
			else
				data[#data + 1] = {
					hostname = client.hostname,
					ipaddr = client.ip,
					macaddr = client.mac,
					wire_type = client.wire_type
				}
			end
		end
    end
    return data
end

function get_internet_status(http_form, phy_state)
    local sys = require "luci.sys"
    local internet = require("luci.model.internet").Internet()
    local ret={internet_status = "", internet_v6_status = ""}

    local mode = uci_r:get("sysmode", "sysmode", "mode") or "router"
    if mode == "ap" then
        local wan_condition = util.exec("status wan_status")
        local status = get_connect_status()
        for i=1, #status do
            if status[i] == "connected"
            then
                wan_condition = "connected"
                break
            end
        end
        if wan_condition == "unconnected"
        then
            wan_condition = "disconnected"
        end

        if phy_state == "true" and wan_condition == "connected" then
            ret.internet_status = "connected"
            ret.internet_v6_status = "connected"
            return ret
        end

        if sys.call("online-test") == 0 and wan_condition == "connected" then
            ret.internet_status = "connected"
            ret.internet_v6_status = "connected"
            return ret
        elseif sys.call("online-test") ~= 0 and wan_condition == "connected" then
            ret.internet_status = "poor_connected"
            ret.internet_v6_status = "poor_connected"
            return ret
        end

        -- fix bug 190502
        -- ret.internet_status = "disconnected"
        -- ret.internet_v6_status = "disconnected"
        ret.internet_status = "unplugged"
        ret.internet_v6_status = "unplugged"
        return ret
    end

    if not _ubus then
        _ubus = ubus.connect()
    end

    local link
    if _ubus then
        local wan = _ubus:call("network.interface.wan", "status", {})
        if wan then
            local ifname = wan.device
            wan = _ubus:call("network.device", "status", {name = ifname})
            if wan then
                link = wan.link
            end
        end
    end

    if not link then
        if phy_state == "true" then
            ret.internet_status = "disconnected"
            ret.internet_v6_status = "disconnected"
            return ret
        else
            ret.internet_status = "unplugged"
            ret.internet_v6_status = "unplugged"
            return ret
        end
    end

    local online = false
    local statusv4 = internet:status()
    local statusv6 = internet:status(true)
    if phy_state == "true" then
        if statusv4 == "connected" or statusv6 == "connected" or statusv4 == "connecting" or statusv6 == "connecting" then
            ret.internet_status = "connected"
            ret.internet_v6_status = "connected"
            return ret
        else
            ret.internet_status = "disconnected"
            ret.internet_v6_status = "disconnected"
            return ret
        end
    end
    if statusv4 == "connected" or statusv6 == "connected" then
        if sys.call("online-test") == 0 then
            online = true
        else
            online = false
        end
    end

    ---IPV4 Status
    if statusv4 == "connected"	then
        if online == true then
            ret.internet_status = "connected"
        else
            ret.internet_status = "poor_connected"
        end
    elseif statusv4 == "connecting" then
        ret.internet_status = "connecting"
    else
        ret.internet_status = "disconnected"
    end

    ---IPV6 status
    if statusv6 == "connected" then
        if online == true then
            ret.internet_v6_status = "connected"
        else
            ret.internet_v6_status = "poor_connected"
        end
    elseif statusv6 == "connecting" then
        ret.internet_v6_status = "connecting"
    else
        ret.internet_v6_status = "disconnected"
    end

    return ret
end

function get_tmp_conn_status()
	ret = {}
	local ret_status = get_internet_status()
	local internet_v4_status = ret_status.internet_status
	local internet_v6_status = ret_status.internet_v6_status
	
	if internet_v4_status == "unplugged" or internet_v6_status == "unplugged" then
		ret.conn_status = "unplugged"
	elseif internet_v4_status == "connected" or internet_v6_status == "connected" then
		ret.conn_status = "connected"
	elseif internet_v4_status == "connecting" or internet_v6_status == "connecting" then
		ret.conn_status = "connecting"
	else
		ret.conn_status = "disconnected"
	end
	-- 	ret.conn_status = get_internet_status().internet_status
	local usbmodem = require "luci.controller.admin.usbmodem"
	if usbmodem then
		usbmodem_info = usbmodem.get_status_mobile()
		--3g4g connect
		if tonumber(usbmodem_info.conn_type) == 1 then
			if usbmodem_info.modem_connstatus == 1 then
				ret.conn_status = "connected"
			end
		end
	end
	return ret
end

function get_tmp_status()
    local configtool = require "luci.sys.config"
    local nw         = require "luci.model.nwcache"
    local accountmgnt = require"luci.model.accountmgnt"
    local cloud_account = accountmgnt.cloud_account_exist()
    local factory = uci_r:get("quicksetup", "quick_setup", "to_show") == 'true' and "true" or "false"
    local initial_passwd = accountmgnt.is_dft_cfg()

    local ret = {}
    local nw  = nw.init()
    local net = nw:get_network("lan")
    local ifc = net and net:get_interface()

    local ipaddr    = net and net:ipaddr()
    local macaddr   = ifc:mac()
    local maskaddr  = net:netmask() or uci_r:get("network", "lan", "netmask")

    ret.conn_type   = uci_r:get("network", "wan", "wan_type") or "disconnected"
    ret.ip_addr     = ipaddr or "0.0.0.0"
    ret.mac_addr    = macaddr
    -- ret.conn_status = get_internet_status().internet_status
    ret.hostname    = configtool.getsysinfo("product_name") or ""
    ret.product     = configtool.getsysinfo("device_name") or ""
    ret.company     = configtool.getsysinfo("FIRM") or ""
    -- ret.traffice_supported = uci_r:get("tfstats", "switch", "enable") and "on" or "off"
    ret.traffice_supported = "off"
    ret.traffice_enabled = uci_r:get("tfstats", "switch", "enable") or "off"
    ret.hardware_ver = configtool.getsysinfo("HARDVERSION")
    ret.software_ver = configtool.getsysinfo("SOFTVERSION")

    local usbmodem = require "luci.controller.admin.usbmodem"
    if usbmodem then
        usbmodem_info = usbmodem.get_status_mobile()
        --3g4g connect
        if tonumber(usbmodem_info.conn_type) == 1 then
            ret.conn_type    = "3G4G"
        end
    end
    if initial_passwd then
        ret.factory_default = "2"
    elseif factory == "true" then
        ret.factory_default = "1"
    else
        ret.factory_default = "0"
    end
    if cloud_account then
        ret.login_mode = "emailandpass"
    else
        ret.login_mode = "password"
    end

    local sys = require "luci.sys"
    local def_mac = sys.exec("getfirm MAC")
	local util   = require "luci.util"
    def_mac         = util.trim(def_mac)
	
	ret.def_mac     = def_mac
    return ret
end


function split(srcString, dlmString)
    local startIndex = 1
    local splitIndex = 1
    local splitArray = {}
    while true do
        local endIndex = string.find(srcString, dlmString, startIndex)
        if not endIndex then
            splitArray[splitIndex] = string.sub(srcString, startIndex, string.len(srcString))
            break
        end
        splitArray[splitIndex] = string.sub(srcString, startIndex, endIndex-1)
        startIndex = endIndex + string.len(dlmString)
        splitIndex = splitIndex + 1
    end
    return splitArray
end

function get_connect_status()
    local string = util.exec("status lan_status")
    local connect_status = split(string, " ")
    return connect_status
end

function get_negotiation_speed()
    local speed_info = util.exec("status speed")
    local speed = split(speed_info, " ")
    return speed
end

function get_negotiation_duplex()
    local duplex_info = util.exec("status duplex")
    local duplex = split(duplex_info, " ")
    return duplex
end

function get_lan_status(http_form, phy_state)
    local status = get_connect_status()
    local speed  = get_negotiation_speed()
    local duplex  = get_negotiation_duplex()
    
    local wan_condition
    local mode = uci_r:get("sysmode", "sysmode", "mode") or "router"
    if mode == "ap" then
        wan_condition = util.exec("status wan_status")
        if wan_condition == "unconnected"
        then
            wan_condition = "disconnected"
        end
    else
        wan_condition = get_internet_status(http_form, phy_state).internet_status
    end

    local data = {}
    --local wan = {wan_status = wan_condition, wan_speed = tonumber(speed[1]:match("(%d+)")), wan_duplex = duplex[1] == "NONE" and "" or duplex[1]}
    local wan_duplex_val = duplex[1] == "NONE" and "" or duplex[1]  
	local wan = {wan_status = wan_condition, wan_speed = wan_condition == "disconnected" and "" or tonumber(speed[1]:match("(%d+)")), wan_duplex = wan_condition == "disconnected" and "" or wan_duplex_val }
    data[1] = wan
    for i=1, #status do
        local tmp_lan_status = {}
        tmp_lan_status["lan" .. i .. "_status"] = status[i]
        if status[i] == "unconnected"
        then
            tmp_lan_status["lan" .. i .. "_speed"] = ""
        else
            tmp_lan_status["lan" .. i .. "_speed"] = tonumber(speed[i+1]:match("(%d+)"))
        end
        if status[i] == "unconnected"
        then
            tmp_lan_status["lan" .. i .. "_duplex"] = ""
        else
            tmp_lan_status["lan" .. i .. "_duplex"] = duplex[i+1]
        end
        data[i+1] = tmp_lan_status
    end
    return data
end

-- General controller routines

local dispatch_tbl = {
    all = {
        [".super"] = {cb = get_all}
    },
    perf = {
        [".super"] = {cb = get_perf}
    },
    access_devices_wired = {
        [".super"] = {cb = get_access_devices, args = "wired"}
    },
    access_devices_wireless_host = {
        [".super"] = {cb = get_access_devices, args = "host"}
    },
    access_devices_wireless_guest = {
        [".super"] = {cb = get_access_devices, args = "guest"}
    },
    internet = {
        [".super"] = {cb = get_internet_status}
    },
    webmobile_all = {
        [".super"] = {cb = get_webmobile_all}
    },
    tmp_status = {
        ["read"] = {cb = get_tmp_status},
        ["conn_status"] = {cb = get_tmp_conn_status},
    },
    router = {
        ["read"] = {cb = get_lan_status, args = "true"}
    }
}

function dispatch(http_form)
    return ctl.dispatch(dispatch_tbl, http_form)
end

function _index()
    return ctl._index(dispatch)
end

function index()
    entry({"admin", "status"}, call("_index")).leaf = true
end
