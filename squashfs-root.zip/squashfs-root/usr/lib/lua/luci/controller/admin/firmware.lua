--[[Copyright(c) 2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  firmware.lua
Details :  firmware http response operation
Author  :  He Ye  <heye@tp-link.net>
Version :  1.0.0
Date    :  27Mar, 2014
]]--

local uci       = require "luci.model.uci"
local http      = require "luci.http"
local debug     = require "luci.tools.debug"
local parttbl   = require "luci.tools.parttbl"
local sys       = require "luci.sys"
local nixio     = require "nixio"
local ctl       = require "luci.model.controller"
local cfgtool 	= require "luci.sys.config"
local util   	= require "luci.util"
--local cloud     = require "cloud_cli"

module("luci.controller.admin.firmware", package.seeall)
local uci_r    = uci.cursor()
local FIRMWARE_STATUS_TBL = {success = "747401", file_size_failed = "747402", file_content_failed = "747403", resore_success = "747404", locking = "747405"}
local FIRMWARE_STATUS_FILE = "/tmp/firmware_laststatus.log"
local FIRMWARE_LOCK_FILE = "/tmp/firmware.lock"
local FIRMWARE_SUCCESS_FILE = "/tmp/firmware.success"

local MODEL = cfgtool.getsysinfo("product_name") or "TL-WR842v3"



function index()
    entry({"admin", "firmware"}, call("firmware_index")).leaf = true
end

local function image_supported()
    -- XXX: yay...
    return ( 0 == os.execute(
        ". /lib/functions.sh; " ..
        "include /lib/upgrade; " ..
        "platform_check_image %q >/dev/null"
            % image_tmp
    ) )
end

local function write_json(data)
    http.prepare_content("text/html")
    http.write_json(data)
end

local function ret_json(suc, code, d)
    return {success = suc, errorcode = code, data = d}
end

local function get_mtd( part_name )
    local string  = require "string"
    
    local file    = io.input("/proc/mtd")

    while true do
        local lines = file:read("*line")
        if not lines then return nil end
        if string.match(lines, '%"' .. part_name .. '%"') then
            return string.match(lines, "mtd%d+")
        end
    end
end

function clean_mem()
    debug.printf("clean memory ...")
    os.execute("ps | grep hotplug2 >/dev/null 2>&1 && killall -9 hotplug2 >/dev/null 2>&1")
    os.execute("ps | grep tddp >/dev/null 2>&1 && killall -9 tddp >/dev/null 2>&1")
--    os.execute("ps | grep tmpServer >/dev/null 2>&1 && killall -9 tmpServer >/dev/null 2>&1")
    os.execute("ps | grep dosd >/dev/null 2>&1 && killall -9 dosd >/dev/null 2>&1")
    os.execute("ps | grep dropbear >/dev/null 2>&1 && killall -9 dropbear >/dev/null 2>&1")
    os.execute("ps | grep factory_reset >/dev/null 2>&1 && killall -9 factory_reset >/dev/null 2>&1")
    os.execute("ps | grep improxy >/dev/null 2>&1 && killall -9 improxy >/dev/null 2>&1")
    os.execute("ps | grep logd >/dev/null 2>&1 && killall -9 logd >/dev/null 2>&1")
    os.execute("ps | grep klogd >/dev/null 2>&1 && killall -9 klogd >/dev/null 2>&1")
    os.execute("ps | grep logger >/dev/null 2>&1 && killall -9 logger >/dev/null 2>&1")
    os.execute("ps | grep openvpn >/dev/null 2>&1 && killall -9 openvpn >/dev/null 2>&1")
    os.execute("ps | grep pptpd >/dev/null 2>&1 && killall -9 pptpd >/dev/null 2>&1")
    os.execute("ps | grep imbd >/dev/null 2>&1 && killall -9 imbd >/dev/null 2>&1")
    os.execute("ps | grep radvd >/dev/null 2>&1 && killall -9 radvd >/dev/null 2>&1")
    os.execute("ps | grep dhcp6s >/dev/null 2>&1 && killall -9 dhcp6s >/dev/null 2>&1")
    os.execute("ps | grep dhcp6c >/dev/null 2>&1 && killall -9 dhcp6c >/dev/null 2>&1")
    os.execute("[ -f /usr/sbin/miniupnpd ] && rm /usr/sbin/miniupnpd >/dev/null 2>&1")
    os.execute("ps | grep miniupnpd >/dev/null 2>&1 && killall -9 miniupnpd >/dev/null 2>&1")
    os.execute("[ -f /usr/sbin/sysmond ] && rm /usr/sbin/sysmond >/dev/null 2>&1")
    os.execute("ps | grep sysmond >/dev/null 2>&1 && killall -9 sysmond >/dev/null 2>&1")
    os.execute("ps | grep crond >/dev/null 2>&1 && killall -9 crond >/dev/null 2>&1")
    os.execute("ps | grep tsched >/dev/null 2>&1 && killall -9 tsched >/dev/null 2>&1")
    os.execute("ps | grep ntpd >/dev/null 2>&1 && killall -9 ntpd >/dev/null 2>&1")
    os.execute("ps | grep improxy >/dev/null 2>&1 && killall -9 improxy >/dev/null 2>&1")
    os.execute("ps | grep wireless_button >/dev/null 2>&1 && killall -9 wireless_button >/dev/null 2>&1")
	os.execute("ps | grep cloud-client >/dev/null 2>&1 && killall -9 cloud-client >/dev/null 2>&1")
	os.execute("ps | grep cloud-brd >/dev/null 2>&1 && killall -9 cloud-brd >/dev/null 2>&1")
    os.execute("echo 3 > /proc/sys/vm/drop_caches")
end

local function image_check(filepath)

    local cry = require "luci.model.crypto"

    if nixio.fs.access(filepath) then
        luci.sys.exec('mkdir /tmp/check')
        luci.sys.exec("tail -c +34 " .. filepath .. " > /tmp/check/check.cry")
        luci.sys.exec('head -c 32 ' .. filepath .. ' > /tmp/check/check.md5')
        luci.sys.exec('echo "  /tmp/check/check.cry" >> /tmp/check/check.md5')

        local result = luci.sys.fork_call('md5sum -c /tmp/check/check.md5 >/dev/null 2>&1')
        if result ~= 0 then
            debug.printf("error:check first md5 failed:" .. tostring(result))
            luci.sys.exec("rm /tmp/check -rf >/dev/null 2&1")
            return false
        end

        debug.printf("decry")
		local cryfunc = cry.dec_file("/tmp/check/check.cry", "777")
        --cry.dec_file("/tmp/check/check.cry", "/tmp/check/check.tar", "0123456789abcdef    ")
        cry.dump_to_file(cryfunc,"/tmp/check/check.tar")

        debug.printf("untar")
        result = luci.sys.fork_call("tar -xvf /tmp/check/check.tar -C /tmp/check/ >/dev/null 2>&1")
        if result ~= 0 then
                        debug.printf("error:untar fail:".. result)
            luci.sys.exec("rm /tmp/check -rf >/dev/null 2&1")
                        return false
                end
        
        debug.printf("image_check")
        if nixio.fs.access("/tmp/check/check") then
            result = luci.sys.fork_call("cd /tmp/check;md5sum -c check >/dev/null 2>&1;cd -")

            if result == 0 then
                -- debug.printf("success")
                luci.sys.exec("rm /tmp/check/check* -rf >/dev/null 2>&1")
                return true
            else
                debug.printf("result:" .. tostring(result))
    --                      debug.printf("error:check second md5 failed")
                luci.sys.exec("rm /tmp/check -rf >/dev/null 2&1")
                            return false
            end
        else
            debug.printf("error:no target file")
            luci.sys.exec("rm /tmp/check -rf >/dev/null 2&1")
            return false
        end
    end
end

local function storage_size()
    local size = 0
    if nixio.fs.access("/proc/mtd") then
        for l in io.lines("/proc/mtd") do
            local d, s, e, n = l:match('^([^%s]+)%s+([^%s]+)%s+([^%s]+)%s+"([^%s]+)"')
            if n == "linux" or n == "firmware" then
                size = tonumber(s, 16)
                break
            end
        end
    elseif nixio.fs.access("/proc/partitions") then
        for l in io.lines("/proc/partitions") do
            local x, y, b, n = l:match('^%s*(%d+)%s+(%d+)%s+([^%s]+)%s+([^%s]+)')
            if b and n and not n:match('[0-9]') then
                size = tonumber(b) * 1024
                break
            end
        end
    end
    return size
end



function ltn12_popen(command)

        local fdi, fdo = nixio.pipe()
        local pid = nixio.fork()

        if pid > 0 then
                fdo:close()
                local close
                return function()
                        local buffer = fdi:read(2048)
                        local wpid, stat = nixio.waitpid(pid, "nohang")
                        if not close and wpid and stat == "exited" then
                                close = true
                        end

                        if buffer and #buffer > 0 then
                                return buffer
                        elseif close then
                                fdi:close()
                                return nil
                        end
                end
        elseif pid == 0 then
                nixio.dup(fdo, nixio.stdout)
                fdi:close()
                fdo:close()
                nixio.exec("/bin/sh", "-c", command)
        end
end

function fork_exec(command)
        local pid = nixio.fork()
        if pid > 0 then
                return
        elseif pid == 0 then
                -- change to root dir
                nixio.chdir("/")

                -- patch stdin, out, err to /dev/null
                local null = nixio.open("/dev/null", "w+")
                if null then
                        nixio.dup(null, nixio.stderr)
                        nixio.dup(null, nixio.stdout)
                        nixio.dup(null, nixio.stdin)
                        if null:fileno() > 2 then
                                null:close()
                        end
                end

                -- replace with target command
                nixio.exec("/bin/sh", "-c", command)
        end
end

function fork_reboot()
    fork_exec("sleep 1;reboot")
end

function file_flash(suc, code, totaltime, ops)
    local file = io.open("/tmp/firmware_status.lua", "w")
    local check_cmd   = "check_status = {success = %s, errorcode = \"%s\", data = {totaltime=%d, ops=\"%s\"}}\n"
    file:write(string.format(check_cmd, suc, code, totaltime, ops))
    file:close()
end

function update_fwuppercent(suc, code, percent, ops)
    local file = io.open("/tmp/firmware_status.lua", "w")
    local check_cmd   = "check_status = {success = %s, errorcode = \"%s\", data = {percent=%d, ops=\"%s\"}}\n"
    file:write(string.format(check_cmd, suc, code, percent, ops))
    file:close()
end

function mtd_update_all(parttbl_check)
    local cmd = "echo 'updating...' >/dev/console;cd /tmp/check;mtd erase flash_ipq806x;"
    needreboot = 1
    for i,part_info in ipairs(parttbl_check.part) do
        local part_name   = part_info.name:gsub("0:","")
        part_name = part_name:match('([%w_]+)')
        local part_offset = tostring(part_info.offset - parttbl_check.boardinfo_end)
        if nixio.fs.access("/tmp/check/" .. part_name) then
            if string.find(part_name,"parttbl\0") == nil then
                cmd = cmd .. "mtd write " .. part_name .. " flash_ipq806x" .. " -n -p " .. part_offset .. ";"
            end
        end
    end

    cmd = cmd .. "mtd erase parttbl;mtd write parttbl parttbl;echo 'reboot...' >/dev/console;reboot"
    return cmd, needreboot
end

function mtd_update_sep(parttbl_check)  
    local partitions = {"boardinfo","profile","defconf","softinfo","userconf","HLOS","extern","webpage","log"}
    for i,part_name in ipairs(partitions) do
        if nixio.fs.access("/tmp/check/" .. part_name) then
            needreboot = 1
            sys.fork_exec("mtd erase "..part_name..";mtd write /tmp/check/"..part_name.." "..part_name.." -q -n;rm /tmp/check/" .. part_name)
        end
    end

    if nixio.fs.access("/tmp/check/rootfs") then
        debug.printf("upgrade rootfs")
        needreboot = 0
        -- once rootfs is erase,luci cann't action any more,so need to reboot
        sys.fork_exec("cd /tmp/check;mtd erase rootfs;mtd write rootfs rootfs -q -n; echo 'reboot...' >/dev/console;reboot")
    end
    
    debug.printf("upgrade end")
    if needreboot == 1 then
        debug.printf("reboot...")
        fork_reboot()
    end

    if checkerror == 1 then
        file_flash("false", "err_check", total, "reboot")
    end

    return needreboot
end

function find_default_ip()
    local defaultcfg
    local head,tail,value
    local cry = require "luci.model.crypto"
    --get default ip
    os.execute("nvrammanager -r /tmp/default-config.tar -p  default-config  >/dev/null 2>&1")
	os.execute("tar -xzf /tmp/default-config.tar -C /tmp/  >/dev/null 2>&1")
    local fp = io.open("/tmp/default-config.xml",'r')
    defaultcfg = fp:read("*a")
    fp:close()
    os.execute("rm -f /tmp/default-config.cry  /tmp/default-config.tar /tmp/default-config.xml >/dev/null 2>&1")

	
    head="<interface name=\"lan\">"
    tail="</interface>"
    _,_,value=string.find(defaultcfg, head.."(.-)"..tail)
	
    head="<ipaddr>"
    tail="</ipaddr>"
    _,_,value=string.find(value, head.."(.-)"..tail)
	
    return value
end

function find_userconfig_ip()
    local usercfg
    local head,tail,value
    --get user-config lan ip
    os.execute("nvrammanager -r /tmp/user-config.xml -p  user-config  >/dev/null 2>&1")
    local fp = io.open("/tmp/user-config.xml",'r')
    usercfg = fp:read("*a")
    fp:close()
    os.execute("rm -f /tmp/user-config.xml >/dev/null 2>&1")

	
	local i,j
	j = 0
	--prevent multiple <interface name="lan"></interface>, use while here
	while true do
		head="<interface name=\"lan\">"
		tail="</interface>"
		i,j,value=string.find(usercfg, head.."(.-)"..tail, j)
		if i == nil or j == nil then break end
		head="<ipaddr>"
		tail="</ipaddr>"
		_,_,value=string.find(value, head.."(.-)"..tail)
		if value ~= nil then 
			return value
		end
	end
    return nil
end

local function write_status_to_file(str)
    local fd = io.open(FIRMWARE_STATUS_FILE, "w")
    if type(str) == "string" then
        fd:write(str .. "\n")
    end
    fd:close()
end

local function read_status_form_file()
	local str = ""
	local fd = io.open(FIRMWARE_STATUS_FILE, "r")
	if nil ~= fd then
		str = fd:read("*line")
	end
	return str
end

local function write_lock_to_file() 
    local fd = io.open(FIRMWARE_LOCK_FILE, "w")
    if fd ~= nil then
        fd:write(MODEL.."\n")
        fd:close()
    end
end

local function check_lock_file()
    if nixio.fs.access(FIRMWARE_LOCK_FILE) then
        return true
    else
        return false
    end
end

local function remove_lock_from_file()
    if nixio.fs.access(FIRMWARE_LOCK_FILE) then
        nixio.fs.unlink(FIRMWARE_LOCK_FILE)
    end
end

local function write_success_to_file()
    local fd = io.open(FIRMWARE_SUCCESS_FILE, "w")
    if fd ~= nil then
        fd:write(MODEL.."\n")
        fd:close()
    end
end

local function check_success_file()
    if nixio.fs.access(FIRMWARE_SUCCESS_FILE) then
        return true
    else
        return false
    end
end

local function get_partition_size(partition_name)
	local PARTITION_FILE = "/tmp/partition.txt"
	local partition_size = 0
	os.execute("nvrammanager -s > "..PARTITION_FILE)
	local fp = io.open(PARTITION_FILE, 'r')
	if nil ~= fp then
		repeat
			local line = fp:read("*line")
			if nil ~= line then
				local i, j
				i, j = string.find(line, partition_name)
				if nil ~= i and nil ~= j then
					local pat = "(.-),()"
					local size_pat = "size%s*=%s*(.-)%s*Bytes"
					local part, pos, value
					for part, pos in string.gfind(line, pat) do
						i, j = string.find(part, "size")
						if nil ~= i and nil ~= j then
							_,_,value = string.find(part, size_pat)
							partition_size = tonumber(value)
						end
					end
				end
			end
		until nil == line or partition_size > 0
	end
	os.execute("rm "..PARTITION_FILE)
	return partition_size
end

--temp func below
function delCloudCfgfrom(backupCfg)
	if backupCfg == nil then
		debug.printf("error backupCfg is needed")
		return
	end
	local configtool = require "luci.sys.config"
	--get user config files
	luci.sys.exec("mkdir -p /tmp/backupcfg")
	luci.sys.exec("mv "..backupCfg.." /tmp/user-config.tar")
	luci.sys.exec("tar -xzf /tmp/user-config.tar -C /  >/dev/null 2>&1")
	configtool.xmlToFile("/tmp/user-config.xml", "/tmp/backupcfg")
	
	--hide cloud and account info config
	local hide_files = {"accountmgnt", "cloud_config"}
	for _, f in ipairs(hide_files) do
		luci.sys.exec("rm -f /tmp/backupcfg/config/"..f)
	end
	
	--recreate xml configfiles
	luci.sys.exec("rm -f /tmp/user-config.xml /tmp/user-config.tar")
	configtool.convertFileToXml("/tmp/backupcfg/config", "/tmp/user-config.xml")
	luci.sys.exec("tar -czf /tmp/user-config.tar /tmp/user-config.xml  >/dev/null 2>&1")
	luci.sys.exec("mv /tmp/user-config.tar "..backupCfg)
	luci.sys.exec("rm -rf /tmp/backupcfg /tmp/user-config.xml")
	return
end

function replaceCloudCfgfor(backupCfg)
	if backupCfg == nil then
		debug.printf("error backupCfg is needed")
		return
	end
	local configtool = require "luci.sys.config"
	--get restore config files
	luci.sys.exec("mkdir -p /tmp/restorecfg /tmp/userconfig")
	luci.sys.exec("mv "..backupCfg.." /tmp/user-config.tar")
	luci.sys.exec("tar -xzf /tmp/user-config.tar -C /  >/dev/null 2>&1")
	configtool.xmlToFile("/tmp/user-config.xml", "/tmp/restorecfg")
	luci.sys.exec("rm -f /tmp/user-config.tar /tmp/user-config.xml")
	
	--get uer config file
	luci.sys.exec("nvrammanager -r /tmp/user-config.tar -p user-config >/dev/null 2>&1")
	luci.sys.exec("tar -xzf /tmp/user-config.tar -C /  >/dev/null 2>&1")
	configtool.xmlToFile("/tmp/user-config.xml", "/tmp/userconfig")
	luci.sys.exec("rm -f /tmp/user-config.tar /tmp/user-config.xml")
	
	--not restore cloud and account info to flash
	local hide_files = {"accountmgnt", "cloud_config"}
	for _, f in ipairs(hide_files) do
		luci.sys.exec("cp -f /tmp/userconfig/config/"..f.." /tmp/restorecfg/config/")
	end
	
	--recreate xml from new config files
	configtool.convertFileToXml("/tmp/restorecfg/config", "/tmp/user-config.xml")
	luci.sys.exec("tar -czf /tmp/user-config.tar /tmp/user-config.xml  >/dev/null 2>&1")
	luci.sys.exec("mv /tmp/user-config.tar "..backupCfg)
	luci.sys.exec("rm -rf /tmp/restorecfg /tmp/userconfig /tmp/user-config.xml")
	return
end
--temp func above

function config_factory(all)
		    -- local all = luci.http.formvalue("all")
                    local configtool = require "luci.sys.config"
                    local cloud_account = require "luci.controller.admin.cloud_account"
                    debug.printf("reset to factory config")
					luci.sys.fork_call("ledcli led_all_on")
                   
                    -- reset usb settings
                    debug.printf("erase usb...")
                    luci.sys.fork_call("nvrammanager -e -p usb-config")

                    local uci_r = require("luci.model.uci").cursor()
                    local accmgnt   = require "luci.model.accountmgnt"
                    local complete_flag
                    local unbind_ret = true
                	local user
                    local bind_status = uci_r:get("cloud_config", "device_status", "bind_status")
                    local need_unbind = uci_r:get("cloud_config", "device_status", "need_unbind")

                    -- set "complete_flag = true" when form is nil , or form isn't nil and form.all is true
                    if all == nil or all =="true" then
                        complete_flag = true
                    else
                        complete_flag = false
                    end
	
                    debug.print("complete_flag:", complete_flag)
                    -- config factory incompletely.
                    if complete_flag == false then
                        luci.sys.call("cp /etc/config/accountmgnt /tmp/accountmgnt_bak")
                    else
                        if tonumber(bind_status) == 1 or tonumber(need_unbind) == 1 then
                            cloud_account.cloud_unbind()
                        end

                        --get the unbind result
                        uci_r = require("luci.model.uci").cursor()
                        bind_status = uci_r:get("cloud_config", "device_status", "bind_status")
                        need_unbind = uci_r:get("cloud_config", "device_status", "need_unbind")
                        if tonumber(bind_status) == 1 or tonumber(need_unbind) == 1 then
			                local users = accmgnt.get_cloudAccount()
			                if users and #users ~= 0 then
				                user = type(users) == "table" and users[1] or users
				                if user then
				                 	unbind_ret = false
				                end
			                end
                        end
                    end
                    
                    local factory_id
                    local ifttt_support = uci_r:get_profile("ifttt", "ifttt_support") or "no"
	                  if ifttt_support == "yes" then
		                    factory_id = uci_r:get("ifttt_trigger", "ifttt_config", "factory_id") or "0"
                        factory_id = tonumber(factory_id)
	                  end
	
	            configtool.resetconfig()

                    -- 擦除extern分区, 如有特殊情况的分区，再特殊处理
                    local extern_partitions = uci_r:get_profile("backup_restore", "extern_partition") or nil
                    if extern_partitions ~= nil then
                    	extern_partitions = util.split(extern_partitions, " ")
                    	for i, v in ipairs(extern_partitions) do
                    		if v ~= nil then
                    			os.execute("nvrammanager -e -p " .. v .. " >/dev/null 2>&1")
                    		end
                    	end
                    end					
                    				
                    luci.sys.fork_call("/etc/init.d/logd stop ; logreset")
                    luci.sys.call("[ -f /sbin/board_factory ] && board_factory")
                    configtool.reloadconfig()
                    uci_r = require("luci.model.uci").cursor()
                    if complete_flag == false then
                        luci.sys.call("cp /tmp/accountmgnt_bak /etc/config/accountmgnt")
                        uci_r:set("cloud_config", "device_status", "bind_status", bind_status)
                        uci_r:commit("cloud_config")
                    else
                        if unbind_ret == false then 
                            uci_r:set("cloud_config", "device_status", "need_unbind", "1")
                            uci_r:commit("cloud_config")
                            accmgnt.set_cloudAccount(user.username, user.password, user.accountid)
                        end	
                    end
                    
                    	-- factory id should be auto-increment after factory reset.
	                   if ifttt_support == "yes" then
		                      factory_id = factory_id + 1
		                      uci_r:set("ifttt_trigger", "ifttt_config", "factory_id", tostring(factory_id))
		                      uci_r:commit("ifttt_trigger")
	                   end
                    
                    debug.printf("reboot...")
                    fork_reboot()
end

function config_backup()
        -- 备份extern分区, 如有特殊情况的分区，再特殊处理
        local extern_partitions = uci_r:get_profile("backup_restore", "extern_partition") or nil
        if extern_partitions ~= nil then
       	    extern_partitions = util.split(extern_partitions, " ")
       	    os.execute("mkdir /tmp/backupfolder >/dev/null 2>&1")

       	    for i, v in ipairs(extern_partitions) do
       		    if v ~= nil then
       			    luci.sys.exec("nvrammanager -r /tmp/backupfolder/ori-backup-" .. v .. ".bin -p " .. v .. " >/dev/null 2>&1")
       		    end
       	    end

       	    --打包
       	    luci.sys.exec("nvrammanager -r /tmp/backupfolder/ori-backup-user-config.bin -p user-config >/dev/null 2>&1")
			delCloudCfgfrom("/tmp/backupfolder/ori-backup-user-config.bin")
       	    os.execute("tar -cf /tmp/backup -C /tmp/backupfolder . >/dev/null 2>&1")
       	    luci.sys.exec("rm -rf /tmp/backupfolder >/dev/null 2>&1")
        else
       	    luci.sys.exec("nvrammanager -r /tmp/backup -p user-config >/dev/null 2>&1")
			delCloudCfgfrom("/tmp/backup")
        end		
        --luci.sys.exec("cat /dev/".. get_mtd("userconf") .. " > /tmp/backup")
        --luci.sys.exec("nvrammanager -r /tmp/backup -p  user-config   >/dev/null 2>&1")

        debug.printf("encry")
        local cry = require "luci.model.crypto"
        cry.enc_file("/tmp/backup", "/tmp/backup.cry", "0123456789abcdef    ")
        local reader = require("io").popen("cat /tmp/backup.cry")
        luci.sys.exec("rm /tmp/backup")
		--delete cry files
        luci.sys.exec("rm /tmp/backup.cry")	

        return reader
	             
end

function firmware_index()
    local sys = require "luci.sys"
    local fs  = require "luci.fs"

    local upgrade_avail = nixio.fs.access("/lib/upgrade/platform.sh")
    local reset_avail   = os.execute([[grep '"rootfs_data"' /proc/mtd >/dev/null 2>&1]]) == 0

    local restore_cmd = "tar -xzC/ >/dev/null 2>&1"
    local backup_cmd  = "sysupgrade --create-backup - 2>/dev/null"
    --local image_tmp   = "/tmp/firmware.tar"
    local image_tmp   = "/tmp/firmware.bin"
	local config_tmp = "/tmp/config.bin"
    --reboot_time
    local total = 200
	local backup_restore_total = 95
    local percent

    local ret
    --get file
    local fp
	
	local uploadFileSize = 0
	
	--according to nvrammanager sysUpfirmware.h, set maximum file size
	local maximumFileSize = 0x2000000 + 0x1000 + 0x10 + 0x04 
	local rejectOneTime = 0
	local firmwareFileName
    luci.http.setfilehandler(
        function(meta, chunk, eof)
		if not check_lock_file() then
            if not fp then
                file_flash("true", "", total, "upload") 
                if meta and meta.name == "image" then
                --  debug.printf("open file image") 
                --  debug.printf(os.clock())
					firmwareFileName = image_tmp  
                else
                --  fp = io.popen(restore_cmd, "w")
                    firmwareFileName = config_tmp
                --  debug.printf("open file config")
                end
				fp = io.open(firmwareFileName, "w")
				uploadFileSize = 0
            end
            if chunk then
				uploadFileSize = uploadFileSize + #chunk
				if uploadFileSize <= maximumFileSize then
					fp:write(chunk)
				else
					if 0 == rejectOneTime then
						--[[
							echo fail to tmp file only once,
							if input file size is too large, 
							it may be block by other module,
							so add fail flag and 
							remove upload file in this place.
						]]--
						write_status_to_file(FIRMWARE_STATUS_TBL.file_size_failed)
						fp:close()
						os.execute("rm "..firmwareFileName)
						fp = io.open(firmwareFileName, "w")
						rejectOneTime = 1
					end
				end
            --  debug.printf(".")
            --    fp:write(chunk)
            end
            if eof then
                fp:close()
            --  debug.printf("close file")
            --  debug.printf(os.clock())
            end
        end
	end
    )

    local operation = luci.http.formvalue("operation")
    local form = luci.http.formvalue("form")
    
    --print info
--[[    if operation then
        debug.printf("opration:" .. operation)
    end]]--

    local configtool = require "luci.sys.config"

    local action = {
       	["read"]      = function()
                    local sname = uci_r:get_first("system", "system", nil, nil)
                    local restore_time = uci_r:get("system", sname, "restore_time")
                    local firmwareUp_time = uci_r:get("system", sname, "firmwareUp_time")
                    local is_default = uci_r:get("quicksetup", "quick_setup", "to_show") == 'true' or false
                    if form == "upgrade" then
						--remove last result file
						os.execute("rm -f "..FIRMWARE_STATUS_FILE.." >/dev/null 2>&1")
                        ret = ret_json(true,"", 
                                {hardware_version = configtool.getsysinfo("HARDVERSION"), 
                                firmware_version = configtool.getsysinfo("SOFTVERSION") .. "(" .. string.sub(configtool.getsysinfo("special_id") or "null", 1, 4) .. ")",
                                is_default = is_default,
                                totaltime = firmwareUp_time})
				        if is_default == true then
                            sys.fork_exec("uci set quicksetup.quick_setup.to_show=false;uci commit quicksetup;uci_commit_flash")    
				        end
                    elseif form == "config" then
						--remove last result file
						os.execute("rm -f "..FIRMWARE_STATUS_FILE.." >/dev/null 2>&1")
                        ret = ret_json(true,"",{totaltime = restore_time})
                    else
						-----tag1 ---
						
                        ret = ret_json(false,"not exist","")
                    end
                end,
        ["check"]     = function()
                    if nixio.fs.access("/tmp/firmware_status.lua") then
                        dofile("/tmp/firmware_status.lua")
                        ret = check_status
                    else
                        ret = ret_json(true,"","")
                        return
                    end
                end,        
        ["fwup_check"]     = function()
                    local ubus = require "ubus"
                    local _ubus = ubus.connect()
                    local UBUS_OBJECT = "nvram_ubus"
                    local fwup_percent  = _ubus:call(UBUS_OBJECT, "getFwupPercent", {})
					if fwup_percent ~= nil then
						percent = fwup_percent.percent
						
						if percent >= 0 then
							debug.printf("=======fwup_check==========percent = " .. percent)
							update_fwuppercent("true", "", percent, "flash")
							debug.printf("1")	
							if nixio.fs.access("/tmp/firmware_status.lua") then
								debug.printf("2")
								dofile("/tmp/firmware_status.lua")
								ret = check_status
							else
								debug.printf("3")
								ret = ret_json(true,"","")
								return
							end
						else
							debug.printf("4")
							ret = ret_json(false, "err_form", "")
						end
						
						if percent == 100 then
						    debug.printf("upgrade true")
                            local uci_r = require("luci.model.uci").cursor()
                            --local dl_percent = uci_r:get("cloud_status", "client_info", "fw_download_progress") 
                            --if tonumber(dl_percent) >= 100 then
                            if not nixio.fs.access(image_tmp) then -- cloud upgrade, clear cloud upgrade uci config.
								debug.printf("4")
                                uci_r:delete("cloud_config", "new_firmware")
                                uci_r:delete("cloud_config", "upgrade_info")
                                uci_r:set("cloud_config", "new_firmware", "cloud_push")
                                uci_r:set("cloud_config", "upgrade_info", "cloud_reply")
                                uci_r:set("wportal", "upgrade", "enable", "yes")
                                uci_r:set("wportal", "upgrade", "time", "0")
                                uci_r:set("cloud_config", "info", "show_flag", "0")
                                uci_r:commit("cloud_config")
                            end
							debug.printf("reboot...")
							--fork_reboot()
						end
					else
						-------tag2 ----
                            ret = ret_json(false, "permission denied", "")
                    end
                end,        
        ["reboot"]    = function()
                    ret = ret_json(true,"",true)
                    debug.printf("reboot...")
                    fork_reboot()
                end,
        ["factory"]   = function()                  
			local ipaddr = find_default_ip()
			ret = ret_json(true ,"",{
				default_ip = ipaddr
			})

                    config_factory(luci.http.formvalue("all"))
                end,
        ["backup"]    = function()
                    -- 备份extern分区, 如有特殊情况的分区，再特殊处理
                    local extern_partitions = uci_r:get_profile("backup_restore", "extern_partition") or nil
                    if extern_partitions ~= nil then
                   	    extern_partitions = util.split(extern_partitions, " ")
                   	    os.execute("mkdir /tmp/backupfolder >/dev/null 2>&1")
			
                   	    for i, v in ipairs(extern_partitions) do
                   		    if v ~= nil then
                   			    luci.sys.exec("nvrammanager -r /tmp/backupfolder/ori-backup-" .. v .. ".bin -p " .. v .. " >/dev/null 2>&1")
                   		    end
                   	    end
			
                   	    --打包
                   	    luci.sys.exec("nvrammanager -r /tmp/backupfolder/ori-backup-user-config.bin -p user-config >/dev/null 2>&1")
						delCloudCfgfrom("/tmp/backupfolder/ori-backup-user-config.bin")
                   	    os.execute("tar -cf /tmp/backup -C /tmp/backupfolder . >/dev/null 2>&1")
                   	    luci.sys.exec("rm -rf /tmp/backupfolder >/dev/null 2>&1")
                    else
                   	    luci.sys.exec("nvrammanager -r /tmp/backup -p user-config >/dev/null 2>&1")
						delCloudCfgfrom("/tmp/backup")
                    end		
                    --luci.sys.exec("cat /dev/".. get_mtd("userconf") .. " > /tmp/backup")
                    --luci.sys.exec("nvrammanager -r /tmp/backup -p  user-config   >/dev/null 2>&1")

                    debug.printf("encry")
                    local cry = require "luci.model.crypto"
                    cry.enc_file("/tmp/backup", "/tmp/backup.cry", "0123456789abcdef    ")
					local reader = ltn12_popen("cat /tmp/backup.cry")
                    luci.http.header('Content-Disposition', 'attachment; filename="backup-%s-%s.bin"' % {
                        luci.sys.hostname(), os.date("%Y-%m-%d")})
                    luci.http.prepare_content("application/x-bin")
                    luci.ltn12.pump.all(reader, luci.http.write)
                    luci.sys.exec("rm /tmp/backup")
					--delete cry files
                    luci.sys.exec("rm /tmp/backup.cry")		
					write_status_to_file(FIRMWARE_STATUS_TBL.success)                  
                    return    
                end,
        ["restore"]   = function()
					local cry = require "luci.model.crypto"
					local fs  = require "luci.fs"
					local BACKUP_ORIGIN_FILENAME = "/tmp/backup"
					local BACKUP_PARTITION_MATCHNAME = "user%-config"
					local BACKUP_PARTITION_NAME = "user-config"
					-- 恢复extern分区, 如有特殊情况的分区，再特殊处理
					local extern_partitions = uci_r:get_profile("backup_restore", "extern_partition") or nil
					if extern_partitions ~= nil then
						extern_partitions = util.split(extern_partitions, " ")
						if uploadFileSize < 600000 then
						    debug.printf("decry")
							cry.dec_file(config_tmp, BACKUP_ORIGIN_FILENAME, "0123456789abcdef    ")
							
						    os.execute("mkdir /tmp/restore >/dev/null 2>&1")
						    --解压
						    os.execute("tar -xf "..BACKUP_ORIGIN_FILENAME.." -C /tmp/restore >/dev/null 2>&1")
			
						    for i, v in ipairs(extern_partitions) do
							    if v ~= nil then
								    local filesize = fs.stat("/tmp/restore/ori-backup-" .. v .. ".bin").size
									local backup_max_size = get_partition_size(v)
									if filesize > 0 and filesize <= backup_max_size then
									    luci.sys.exec("nvrammanager -e -p " .. v .. " >/dev/null 2>&1")
										luci.sys.exec("nvrammanager -w /tmp/restore/ori-backup-" .. v .. ".bin -p ".. v .. " >/dev/null 2>&1")
									else
									    luci.sys.exec("nvrammanager -e -p " .. v .. " >/dev/null 2>&1")
									end
								end
							end
							
							replaceCloudCfgfor("/tmp/restore/ori-backup-user-config.bin")
					        local backup_max_size = get_partition_size(BACKUP_PARTITION_MATCHNAME)
							local backup_file = fs.stat("/tmp/restore/ori-backup-user-config.bin")
						    if backup_file.size > 0 and backup_file.size <= backup_max_size then
							    debug.printf("restore")
							    luci.sys.exec("nvrammanager -e -p  user-config   >/dev/null 2>&1")
							    luci.sys.exec("nvrammanager -w /tmp/restore/ori-backup-user-config.bin -p  user-config   >/dev/null 2>&1")
							    debug.printf("restore configs")
							    ret = ret_json(true, "", "")							
							    write_status_to_file(FIRMWARE_STATUS_TBL.resore_success)							
							    debug.printf("reboot...")
							    fork_reboot()
						    else
							    ret = ret_json(false, "file content error", "")
							    write_status_to_file(FIRMWARE_STATUS_TBL.file_content_failed)
							    debug.printf("Decry file failed")
						    end
							luci.sys.exec("rm "..BACKUP_ORIGIN_FILENAME)
							luci.sys.exec("rm -rf /tmp/restore")
						else
							-----tag3--
						    ret = ret_json(false, "file size exceeds", "")
						    write_status_to_file(FIRMWARE_STATUS_TBL.file_size_failed)
						    debug.printf("Upload file is too large, plz check")
					    end	
						
					else
					    --obtain backup partition size
					    local backup_max_size = get_partition_size(BACKUP_PARTITION_MATCHNAME)
					    --check bin file size
					    if uploadFileSize < backup_max_size + 16 then
					    --bin file is encry by aes-256 algorithm, add 16.
						    debug.printf("decry")
							cry.dec_file(config_tmp, BACKUP_ORIGIN_FILENAME, "0123456789abcdef    ")
							replaceCloudCfgfor(BACKUP_ORIGIN_FILENAME)
						    local backup_file = fs.stat(BACKUP_ORIGIN_FILENAME)
						    if backup_file.size > 0 and backup_file.size <= backup_max_size then
							    debug.printf("restore")
							    luci.sys.exec("nvrammanager -e -p  user-config   >/dev/null 2>&1")
							    luci.sys.exec("nvrammanager -w "..BACKUP_ORIGIN_FILENAME.." -p  user-config   >/dev/null 2>&1")
							    debug.printf("restore configs")
							    ret = ret_json(true, "", "")							
							    write_status_to_file(FIRMWARE_STATUS_TBL.resore_success)							
							    debug.printf("reboot...")
							    fork_reboot()
						    else
							    ret = ret_json(false, "file content error", "")
							    write_status_to_file(FIRMWARE_STATUS_TBL.file_content_failed)
							    debug.printf("Decry file failed")
						    end
						    luci.sys.exec("rm "..BACKUP_ORIGIN_FILENAME)
					    else
						    -------tag4-------
							ret = ret_json(false, "file size exceeds", "")
						    write_status_to_file(FIRMWARE_STATUS_TBL.file_size_failed)
						    debug.printf("Upload file is too large, plz check")
					    end	
					end					
                end,
				------important tag5------
        ["firmware"]  = function()
                    debug.printf("upgrade firmware...")  
                    --debug.printf("upfile path = " .. image_tmp)
        
                    if nixio.fs.access(image_tmp) then
                        debug.printf("true")
						local firmCheckRet = nil
                            --sys.fork_exec("nvrammanager -u  " .. image_tmp .. ">/dev/console 2>&1")
						firmCheckRet = sys.fork_call("nvrammanager -c  " .. image_tmp .. ">/dev/console 2>&1")
                        if firmCheckRet ~= 0 then
                            -----tag6-----
							ret = ret_json(false, "err_form", "")
                            return
                        end
                        else
                            debug.printf("false")
                            return
                        end
                        --according ret val, determine success or not
                        write_status_to_file(FIRMWARE_STATUS_TBL.success)
                        ret = ret_json(true, "", "")
                    --debug.printf("reboot...")
                    --fork_reboot()
                    
                --[[ 
                    local needreboot = 0
                    local checkerror = 0
                    local cmd        = ""
                    debug.printf("unpack")
                    
                    local result = image_check("/tmp/firmware.tar")
                    ret = ret_json(true, "", "")

                    if result == true then
                        debug.printf("true")
                        file_flash("true", "", total, "flash")
                    else
                        debug.printf("false")
                        file_flash("false", "err_check", total, "flash")
                    end

                    debug.printf("start to flash")

                    -- parttbl first
                    if nixio.fs.access("/tmp/check/parttbl") then
                        debug.printf("check parttbl")
                        local parttbl_check = {}
                        parttbl_check = parttbl.parttbl_check("/dev/" .. get_mtd("parttbl"), "/tmp/check/parttbl")
                        if parttbl_check.same == 0 then
                            if parttbl_check.magic and parttbl_check.flash_size and parttbl_check.rootfs and parttbl_check.kernel then
                                debug.printf("mtd_update_all")
                                cmd,needreboot = mtd_update_all(parttbl_check)
                                debug.printf(cmd)
                                sys.fork_exec(cmd)
                            else
                                debug.dumptable(parttbl_check)
                                debug.printf("parttbl check failed")
                                return
                            end
                        else
                            debug.printf("mtd_update_sep")
                            needreboot = mtd_update_sep(parttbl_check)
                        end
                    end
                --]] 
                --  fork_exec("killall dropbear uhttpd; sleep 1; /sbin/sysupgrade %s %q" %{ keep, image_tmp })
                end,
				----important tag7----
		["checklast"] = function()
                    local lastres = read_status_form_file()
                    if nil == lastres or "" == lastres then
						ret = ret_json(false,"permission denied","")
                    elseif FIRMWARE_STATUS_TBL.success == lastres then
                        sys.fork_exec("/sbin/sysupgrade " .. image_tmp .. "> /dev/console 2>&1")
                        ret = ret_json(true,"","")
                    elseif FIRMWARE_STATUS_TBL.resore_success == lastres then
                        local ipaddr = find_userconfig_ip()
                        ret = ret_json(true,"",{default_ip = ipaddr})
                    elseif FIRMWARE_STATUS_TBL.file_size_failed == lastres then
						ret = ret_json(false,"file size exceeds","")
                    elseif FIRMWARE_STATUS_TBL.file_content_failed == lastres then
						ret = ret_json(false,"file content error","")
                    elseif FIRMWARE_STATUS_TBL.locking == lastres then
						ret = ret_json(false,"locking","")
                    else
						ret = ret_json(false,"unknown error","")
                    end
                    if nixio.fs.access(FIRMWARE_STATUS_FILE) then
                        os.execute("rm -f "..FIRMWARE_STATUS_FILE.." >/dev/null 2>&1")
                    end
                end,
    }

    if uploadFileSize > maximumFileSize then
		ret = ret_json(false, "file size exceeds", "")
	else
		local fun = action[operation]
		if fun then
			fun()	
		else
			ret = ret_json(false, "not exist", {["operation"] = operation})
		end
	end
	--[[
	1)remove image -- nvrammanager's responsibility
	2)remove config -- firmware.lua's responsibility
	]]--
	if config_tmp == firmwareFileName then
		os.execute("rm "..firmwareFileName)
	end
	
	if nil ~= ret then
		write_json(ret)
	end
end

function tmp_reboot()
    debug.printf("reboot...")
    
    local uci_r = require("luci.model.uci").cursor()
    if nixio.fs.access("/etc/config/history_list") then
        uci_r:commit("history_list")
    end
    
    fork_reboot()
end

function tmp_factory()
    debug.printf("reset to factory config")
    config_factory("true") 
end
function clean_firmware_inf()
    local uci_r = require("luci.model.uci").cursor()

    uci_r:delete("cloud_config", "new_firmware")
    uci_r:delete("cloud_config", "upgrade_info")
    uci_r:set("cloud_config", "new_firmware", "cloud_push")
    uci_r:set("cloud_config", "upgrade_info", "cloud_reply")
    uci_r:set("wportal", "upgrade", "enable", "yes")
    uci_r:set("wportal", "upgrade", "time", "0")
    uci_r:set("cloud_config", "info", "show_flag", "0")
    uci_r:commit("cloud_config")
    --sys.fork_exec(". /lib/wportal/wportal.sh && wportalctrl_clear_all")
end
local ERRCODE_IDLE = "0"
local ERRCODE_SUCCESS = "1"
local ERRCODE_FAIL = "-1"

function GetShortName(sName,nMaxCount,nShowCount)
	if sName == nil or nMaxCount == nil then
		return
	end
	
	local sStr = sName
	local tCode = {}
	local tName = {}
	local nLenInByte = #sStr
	local nWidth = 0
	
	if nShowCount == nil then
		nShowCount = nMaxCount - 3
	end
	
	for i=1,nLenInByte do
		local curByte = string.byte(sStr, i)
		local byteCount = 0;
		
		if curByte>0 and curByte<=127 then
			byteCount = 1
		elseif curByte>=192 and curByte<=223 then
			byteCount = 2
		elseif curByte>=224 and curByte<=239 then
			byteCount = 3
		elseif curByte>=240 and curByte<=247 then
			byteCount = 4
		elseif curByte>=248 and curByte<=251 then
			byteCount = 5
		elseif curByte>=252 and curByte<=253 then
			byteCount = 6
		end
		
		local char = nil
		
		if byteCount > 0 then
			char = string.sub(sStr, i, i+byteCount-1)
			i = i + byteCount -1
		end
		
		if byteCount >= 1 then
			nWidth = nWidth + 1
			table.insert(tName,char)
			table.insert(tCode,1)
		end
	end
	
	if nWidth >= nMaxCount then
		local _sN = ""
		local _len = 3
		
		for i=1,#tName do
			_sN = _sN .. tName[i]
			if _len > nShowCount then
				break
			end
			_len = _len + tCode[i]
		end
		sName = _sN .. "..."
	end
	return sName
end

function tmp_get_firmware_info(lua_form)
	local needToCheck = tonumber(lua_form.needToCheck)
	local cloud = require "luci.controller.admin.cloud_account"
	if needToCheck == 1 then
		sys.call("cloud_getFwList")
	end

	local data = {}
    local uci_r = uci.cursor()
	local configtool = require "luci.sys.config"
	data.name = configtool.getsysinfo("product_name") or ""
	data.version = uci_r:get("cloud_config", "upgrade_info", "version") or ""
	if data.version == "" then
		data.version = configtool.getsysinfo("SOFTVERSION") or ""
	end
	local releaseNote = uci_r:get("cloud_config", "upgrade_info", "release_log") or ""
	
	releaseNote = GetShortName(releaseNote,800)
	
	data.releaseNote = nixio.bin.b64encode(releaseNote)
	data.isLatest = uci_r:get("cloud_config", "new_firmware", "fw_new_notify") or "0"
	data.upgradeLevel = uci_r:get("cloud_config", "upgrade_info", "type") or "0"
	return data
end

local function detect_download_status(processcmd)
	local cloud_account = require "luci.controller.admin.cloud_account"
	local ret = cloud_account.get_download_detail(processcmd)
	if not ret then
		return 0, false
	end
	return ret.percent, true
end

function set_download_inf(dl_percent)
	local uci_r = require("luci.model.uci").cursor()
	if tonumber(dl_percent) >= 100 then
		uci_r:delete("cloud_config", "new_firmware")
		uci_r:delete("cloud_config", "upgrade_info")
		uci_r:set("cloud_config", "new_firmware", "cloud_push")
		uci_r:set("cloud_config", "upgrade_info", "cloud_reply")
		uci_r:set("wportal", "upgrade", "enable", "yes")
		uci_r:set("wportal", "upgrade", "time", "0")
		uci_r:set("cloud_config", "info", "show_flag", "0")
		uci_r:set("cloud_config", "info", "tcsp_status", "0")
		uci_r:commit("cloud_config")
		--sys.fork_exec(". /lib/wportal/wportal.sh && wportalctrl_clear_all")
	end
end

function get_upgrade_detail(processcmd)    
    local ret
    local ubus = require "ubus"
    local _ubus = ubus.connect()
    local UBUS_OBJECT = "nvram_ubus"
    local fwup_percent  = _ubus:call(UBUS_OBJECT, "getFwupPercent", {})
    local percent

    if fwup_percent ~= nil then
        percent = fwup_percent.percent
        update_fwuppercent("true", ERRCODE_SUCCESS, percent, "flash")
            
        if nixio.fs.access("/tmp/firmware_status.lua") then
            dofile("/tmp/firmware_status.lua")
            ret = check_status
        else
            return true, percent
        end
        
        if percent >= 100 and processcmd then
            debug.printf("upgrade true")
            --clean cloud upgrade flag after upgrade firmware sucessfully.
            clean_firmware_inf()
                --sys.fork_exec(". /lib/wportal/wportal.sh && wportalctrl_clear_all")

            debug.printf("reboot...")
            sys.fork_exec("sleep 1;reboot")
        end

        return ret, percent
    else
        debug.printf("upgrade false")
        update_fwuppercent("false", ERRCODE_FAIL, 0, "flash")
        sys.fork_exec("ledcli STATUS_ON")
        return false, "err_failed"
    end
end

local dbg      = require "luci.tools.debug"

function fw_check_loop()
	local null = nixio.open("/dev/null", "w+")
	
	if null then
		nixio.dup(null, nixio.stderr)
		nixio.dup(null, nixio.stdout)
		nixio.dup(null, nixio.stdin)
		if null:fileno() > 2 then
			null:close()
		end
	end

	local percent = "0"
	local success = true
	sys.call("sleep 3")
	--download 轮询，以及时激活升级。
	while true do
		percent, success = detect_download_status(false)
		if success == false then 
			return
		end
		if tonumber(percent) >= 100 then
			sys.call("sleep 3")
			break
		end
		sys.call("sleep 3")
	end
	
	sys.call("sleep 3")
	set_download_inf(percent)
	filename = "/tmp/cloud_up.bin"
	return sys.call("/sbin/sysupgrade " .. filename)
end

--[[由于手机端的实现要求只要点击过upgrade按钮，之后就算手机断开也要upgrade成功，因此修改upgrade逻辑：
    在选择了upgrade之后，先执行下载，然后fork一个进程，3秒轮询，调用正常的下载命令。
        ps：正常的下载命令在下载到达100%以后才会主动调用升级进程。
    在获取到下载程度达到100%以后，进行3秒轮询，调用正常的upgrade命令。
        ps：正常的升级固件命令在达到100%以后才会主动调用reboot。
]]--

function fw_upgrade()
	local cloud_account = require "luci.controller.admin.cloud_account"
	
    if false == cloud_account.cloud_fw_upgrade() then
        return false, "illegel download url"
    end
	
	local percent = cloud_account.get_download_progress("/tmp/cloud_up.bin")
	
	--轮询
	local pid = nixio.fork()
	if pid == 0 then
		fw_check_loop()
	end
 	return true, percent
end


function tmp_upgrade_firmware()
	local cloud_account = require "luci.controller.admin.cloud_account"
	local internet_access = cloud_account.check_internet()
	if internet_access == false then 
		return false
	end
    os.execute("touch /tmp/tether_up")
	return fw_upgrade()
end

local UPGRADE_TIME = 75
local REBOOT_TIME = uci.cursor():get_profile("global", "reboot_time") or 75
function tmp_get_upgrade_info()
	local cloud_account = require "luci.controller.admin.cloud_account"
	local status = "idle"
	local process = "0"
	local data = {}

	local ret, errorcode, faildata = cloud_account.get_download_detail(false)
	
	if ret == false then
		sys.call("sleep 1")
		ret, errorcode, faildata = cloud_account.get_download_detail(false)
	end

	if not ret and tonumber(faildata.percent) < 100 then
		status = "fail"
		process = "0"
	else
		status = "downloading"
		process = tostring(ret.percent)
	end
	
	data.status = status
	data.process = process
	data.upgradeTime = UPGRADE_TIME
	data.rebootTime = REBOOT_TIME
	return data
end


local dispatch_tbl = {
    config = {
        ["reboot"]  = { cb  = tmp_reboot },
        ["factory"] = { cb  = tmp_factory}
    },
    tmp_cmd = {
		["get_firmware_info"] = { cb = tmp_get_firmware_info },
		["upgrade_firmware"] = { cb = tmp_upgrade_firmware},
		["get_upgrade_info"] = { cb = tmp_get_upgrade_info}
	}
}

function dispatch(http_form)
    local function hook_cb(success, action)
        if success and action.cmd then
            sys.fork_exec(action.cmd)
        end
        return true
    end
    return ctl.dispatch(dispatch_tbl, http_form, {post_hook = hook_cb})
end
