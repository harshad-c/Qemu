--[[
Copyright(c) 2008-2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  region.lua
Details :  Controller for obtaining regions
Author  :  Ye Qianchuan <yeqianchuan@tp-link.net>
Version :  1.0.0
Date    :  24 Jul, 2014
]]--

module("luci.controller.admin.region", package.seeall)

local uci = require "luci.model.uci"
local sys = require "luci.sys"
local dbg = require "luci.tools.debug"
local ctl = require "luci.model.controller"

local uci_r = uci.cursor()

local SID = {
    ["00000000"] = "UN",
    ["55530000"] = "US",
    ["45550000"] = "EU",
    ["4B520000"] = "KR",
    ["42520000"] = "BR",
    ["4A500000"] = "JP",
    ["43410000"] = "CA",
    ["41550000"] = "AU",
	["52550000"] = "RU",
	["54570000"] = "TW",
}

local COUNTRY_US = {
    "US",
}

local COUNTRY_EU = {
    "BZ", "DE", "GB",
}

local COUNTRY_KR = {
    "KR",
}

local COUNTRY_BR = {
    "AR", "BO", "BR", "CL", "CO", "CR", "EC", "GT", "MX", "PA", "PE", "PY", "SV", "UY", "VE",
}

local COUNTRY_JP = {
    "JP",
}

local COUNTRY_CA = {
    "CA",
}

local COUNTRY_AU = {
    "AU",
}

local COUNTRY_RU = {
    "RU",
}

local COUNTRY_TW = {
    "TW", "US",
}

function getCountryCode()
    sys.call("nvrammanager -r /tmp/productInfo -p product-info");
    local file = io.open("/tmp/productInfo", 'r')
    
    if not file then
        dbg("product info file open failed")
        return "UN"
    end
    
    for line in file:lines() do
        if line:find("special_id:") ~= nil then
            _ , i = line:find("special_id:")
            sid = line:sub(i+1, #line)
            ret = SID[sid]
            file:close()
            sys.exec("rm -f /tmp/productInfo")
            return ret
        end
    end

    file:close()
    sys.call("rm -f /tmp/productInfo")
    return "UN"
end

function regions()
    return function(region_list, i)
        i = i + 1
        local region = region_list[i]
        if region then
            local country_code, country_name, no_autodetect
                = region:match("^([^:]*):([^:]*):([^:]*)$")
            no_autodetect = no_autodetect == "y" and true or nil
            return i, country_code, country_name, no_autodetect
        end
    end, uci_r:get_profile("region", "country"), 0
end

function read_regions()
    local data = {}
    local country = {}

    local countryCode = getCountryCode()
    if countryCode == "US" then
        country = COUNTRY_US
    elseif countryCode == "EU" then
        country = COUNTRY_EU
    elseif countryCode == "KR" then
        country = COUNTRY_KR
    elseif countryCode == "BR" then
        country = COUNTRY_BR
    elseif countryCode == "JP" then
        country = COUNTRY_JP
    elseif countryCode == "CA" then
        country = COUNTRY_CA
    elseif countryCode == "AU" then
        country = COUNTRY_AU
    elseif countryCode == "RU" then
        country = COUNTRY_RU
    elseif countryCode == "TW" then
        country = COUNTRY_TW
    end

    if countryCode == "UN" then
        for _, country_code, country_name, no_autodetect in regions() do
            data[#data + 1] = {
                value = country_code,
                name = country_name,
                no_autodetect = no_autodetect
            }
        end
    else
        for _, country_code, country_name, no_autodetect in regions() do
            for _, k in pairs(country) do
                if k == country_code then
                    data[#data + 1] = {
                        value = country_code,
                        name = country_name,
                        no_autodetect = no_autodetect
                    }
                end
            end
         end
    end

    return data
end

local dispatch_tbl = {
    region = {
        [".super"] = {cb = read_regions}
    }
}

function dispatch(http_form)
    return ctl.dispatch(dispatch_tbl, http_form)
end

function _index()
    return ctl._index(dispatch)
end

function index()
    entry({"admin", "region"}, call("_index")).leaf = true
end
