--[[
Copyright(c) 2008-2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  system.lua
Details :  Controller for various system-wide functions
Author  :  Ye Qianchuan <yeqianchuan@tp-link.net>
Version :  1.0.0
Date    :  19 Jun, 2014
]]--

local wireless = require "luci.controller.admin.wireless"
module("luci.controller.admin.system", package.seeall)

local dbg = require "luci.tools.debug"
local ctl = require "luci.model.controller"
local sys = require "luci.sys"
local uci = require "luci.model.uci"
local uci_r = uci.cursor()

local function get_orig_mac(iface)
    local mac = nil

    mac = sys.exec("firm_mac " .. iface)
    mac = mac:gsub("-", ":")
    return mac
end

local default_mac = get_orig_mac("wan")

local ROUTER_CFG = {
	{MODULE = "administration",		SECTION = "remote",		PARAM = "enable",				TYPE="reverse"},
	{MODULE = "nat",				SECTION = "nat_global",	PARAM = "enable",				TYPE="reverse"},
	{MODULE = "nat",				SECTION = "nat_global",	PARAM = "boost_enable",			TYPE="reverse"},
	{MODULE = "nat",				SECTION = "nat_global",	PARAM = "hnat_enable",			TYPE="reverse"},
	{MODULE = "pptpd",				SECTION = "pptpd",		PARAM = "enabled",				TYPE="reverse"},
	{MODULE = "tfstats",			SECTION = "switch",		PARAM = "enable",				TYPE="reverse"},
	{MODULE = "openvpn",			SECTION = "server",		PARAM = "enabled",				TYPE="reverse"},
	{MODULE = "iptv",				SECTION = "iptv",		PARAM = "igmp_snooping_enable",	TYPE="reverse"},
	{MODULE = "offline_download",	SECTION = "aria2",		PARAM = "enable",				TYPE="reverse"},
	{MODULE = "access_control",		SECTION = "settings",	PARAM = "enable",				TYPE="reverse"},
	{MODULE = "network",			SECTION = "lan",		PARAM = "ipaddr",				TYPE="backup"},
	{MODULE = "network",			SECTION = "lan",		PARAM = "netmask",				TYPE="backup"},
	{MODULE = "network",			SECTION = "lan",		PARAM = "ifname",				TYPE="backup"},
	{MODULE = "network",			SECTION = "wan",		PARAM = "proto",				TYPE="backup"},
	{MODULE = "network",			SECTION = "wan",		PARAM = "type",					TYPE="backup"},
	{MODULE = "network",			SECTION = "wan",		PARAM = "macaddr",				TYPE="backup"},
	{MODULE = "dhcp",				SECTION = "lan",		PARAM = "dhcp_option",			TYPE="backup"},
	{MODULE = "dhcp",				SECTION = "lan",		PARAM = "ignore",				TYPE="backup"}
}

local AP_CFG = {
	{MODULE = "network",		SECTION = "lan",		PARAM = "ipaddr",		TYPE="backup", DFT="192.168.0.254"},
	{MODULE = "network",		SECTION = "lan",		PARAM = "netmask",		TYPE="backup", DFT="255.255.255.0"},
	{MODULE = "network",		SECTION = "lan",		PARAM = "gateway",		TYPE="backup"},
	{MODULE = "network",		SECTION = "lan",		PARAM = "ifname",		TYPE="backup", DFT="eth0.1"},
	{MODULE = "network",		SECTION = "wan",		PARAM = "proto",		TYPE="backup", DFT="dhcp"},
	{MODULE = "network",		SECTION = "wan",		PARAM = "type",			TYPE="backup", DFT=""},
	{MODULE = "network",		SECTION = "wan",		PARAM = "macaddr",		TYPE="backup", DFT= default_mac},
	{MODULE = "dhcp",			SECTION = "lan",		PARAM = "dhcp_option",	TYPE="backup"},
	{MODULE = "dhcp",			SECTION = "lan",		PARAM = "ignore",		TYPE="backup", DFT="2"}
}


local function get_cfg_devsec(ifname)
    local retsec = nil
    uci_r:foreach("network", "device", 
    function(section)
        local name    = section["name"]
        local secname = section[".name"]

        if not retsec and name == ifname then
            retsec = secname
        end
    end)

    return retsec
end


function wan_device_mac_change(flag)
	local wan_ifname = uci_r:get("network", "wan", "ifname")
	local secname = get_cfg_devsec(wan_ifname)
	local new_macaddr = ""
	-- from router to ap
	if flag then
		
		new_macaddr = default_mac or uci_r:get("sysmode", "ap", "network_macaddr")
		-- dbg.printf(new_macaddr)
        if secname then
			if new_macaddr then
				uci_r:set("network", secname, "macaddr", new_macaddr)
				--dbg.printf("router to ap" .. new_macaddr)
			end
        end
	else
	-- from ap to router		
		new_macaddr = uci_r:get("sysmode", "router", "network_macaddr") or default_mac
        if secname then
			if new_macaddr then
            	uci_r:set("network", secname, "macaddr", new_macaddr)
				-- dbg.printf("ap to router" .. new_macaddr)
			end			
        end

	end
	uci_r:commit_without_write_flash("network")		
end



function kickoff_web()
	local sess = sys.exec("basename /tmp/luci-sessions/*")
	if sess ~= "*\n" then 
		sess = string.sub(sess,1,-2)
		local sauth = require "luci.sauth"
		sauth.kill(sess)
	end
end

function logout()
    local sess = require("luci.dispatcher").context.authsession
    if sess then
        local sauth = require "luci.sauth"
        sauth.kill(sess)
    end
    return true
end

function reboot()
    local sys = require "luci.sys"
    local data = { reboot_time = 120 }

    --get reboot time from profile
    data.reboot_time = uci_r:get_profile("global","reboot_time") or 120
	if nixio.fs.access("/etc/config/history_list") then
		uci_r:commit("history_list")
	end
   sys.fork_exec("sleep 1; reboot")
    return data
end

-- >>> sysmode begin

function get_sysmode(mode)
	local data = {}
	
	if nil == uci_r:get("sysmode", "sysmode", "support") then
		data["support"] = "no"
		data["mode"] = "router"
	else
		data["support"] = uci_r:get("sysmode", "sysmode", "support")
		mode    = uci_r:get("sysmode", "sysmode", "mode")
		if nil ~= mode then
			data["mode"] = mode
		else
			data["mode"] = "router"
		end
	end

	return data
end

function set_sysmode(http_form)
	local new_mode = http_form.mode

	if new_mode ~= "router" and new_mode ~= "ap" and new_mode ~= "repeater" then
		return false
	else
			uci_r:set("sysmode", "sysmode", "mode", new_mode)
			uci_r:set("quicksetup", "quick_setup", "to_show", 'true')
			uci_r:commit_without_write_flash("quicksetup")
			if not uci_r:commit_without_write_flash("sysmode") then
				return false
			else
				--luci.sys.call("/sbin/sysmode")
				mode = get_sysmode(new_mode).mode
				change_config(mode)
				return get_sysmode(new_mode)
			end
		--else
			--return get_sysmode()
		--end
	end
end

function sysmode(http_form)
	local operation = http_form.operation
	
	if operation == "write" then
		return set_sysmode(http_form)
	elseif operation == "read" then 
		return get_sysmode()
	else
		return false
	end
end

-- <<< sysmode end

-- <<< Change ip between AP and Router
function change_IP(http_form)
	local sysmode = http_form.mode
	local new_ip
	if sysmode == 'ap' then
		-- recover AP's IP info
		for _,v in pairs(AP_CFG) do
			local cfg_name = v.MODULE .. "_" .. v.PARAM
			local value = uci_r:get("sysmode", "ap", cfg_name)
			if value ~= nil then
				if type(value) == "table" and v.PARAM == "dhcp_option" then
					uci_r:delete("dhcp", "lan", "dhcp_option")
					for _,va in pairs(value) do
						uci_r:set_list(v.MODULE, v.SECTION, v.PARAM, va)
					end
				else
					uci_r:set(v.MODULE, v.SECTION, v.PARAM, value)
				end
				uci_r:commit_without_write_flash(v.MODULE)
			elseif v.DFT ~= nil then
				uci_r:set(v.MODULE, v.SECTION, v.PARAM, v.DFT)
				uci_r:commit_without_write_flash(v.MODULE)
			end
		end
		new_ip = uci_r:get("sysmode", "ap", "network_ipaddr") or uci_r:get("network", "lan", "ipaddr")
	elseif sysmode == 'router' then
		for _,v in pairs(ROUTER_CFG) do
			local cfg_name,value
			if v.TYPE == "backup" then
				cfg_name = v.MODULE .. "_" .. v.PARAM
				value = uci_r:get("sysmode", "router", cfg_name)
				if value ~= nil then
					if type(value) == "table" and v.PARAM == "dhcp_option" then
						uci_r:delete("dhcp", "lan", "dhcp_option")
						for _,va in pairs(value) do
							uci_r:set_list(v.MODULE, v.SECTION, v.PARAM, va)
						end
					else
						uci_r:set(v.MODULE, v.SECTION, v.PARAM, value)
					end
					uci_r:commit_without_write_flash(v.MODULE)
				end
			end
		end
		uci_r:delete("network", "lan", "gateway")
		uci_r:delete("network", "lan", "dns")
		uci_r:commit_without_write_flash("network")
		new_ip = uci_r:get("sysmode", "router", "network_ipaddr")
	end
	uci_r:commit("network")

	if new_ip ~= nil then
		local dhcps = require "luci.controller.admin.dhcps"
		dhcps.dhcp_opt_update(new_ip)
	end

	luci.sys.fork_call("sleep 1;reboot")
	return true
end
-- <<< change ip end

-- <<< Change UCI config between AP and Router
function change_config(sysmode)
	-- switch to AP, backup Router's IP info & disable some func
	if sysmode == 'ap' then
		for _,v in pairs(ROUTER_CFG) do
			local value = uci_r:get(v.MODULE, v.SECTION, v.PARAM)
			if value ~= nil then
				if v.TYPE == "reverse" then
					local cfg_name = v.MODULE .. "_" .. v.SECTION
					uci_r:set("sysmode", "router", cfg_name, value)
					if value == 'on' or value == 'off' then
						uci_r:set(v.MODULE, v.SECTION, v.PARAM, "off")
					else
						uci_r:set(v.MODULE, v.SECTION, v.PARAM, 0)
					end
					uci_r:commit_without_write_flash(v.MODULE)
				else
					local cfg_name = v.MODULE .. "_" .. v.PARAM
					uci_r:set("sysmode", "router", cfg_name, value)
				end
			end
		end
		uci_r:commit_without_write_flash("sysmode")

		local form = {}
		form.form = "guest"
		form.operation = "read"
		local data = wireless.wireless_predefined_forms(form, true)
		uci_r:set("sysmode", "router", "access", data.access)
		uci_r:set("sysmode", "router", "isolate", data.isolate)
		form.operation = "write"
		form.isolate = "off"
		form.access = "on"
		wireless.wireless_predefined_forms(form, true)
		wan_device_mac_change(true)
		uci_r:commit_without_write_flash("sysmode")
	end

	-- switch to Router, backup AP's IP info & recover some func
	if sysmode == 'router' then
		local lan_type = uci_r:get("network", "lan", "lan_type") or ""
		local dhcp_status = uci_r:get("dhcp", "lan", "ignore") or ""
		for _,v in pairs(AP_CFG) do
			local value = uci_r:get(v.MODULE, v.SECTION, v.PARAM)
			if value ~= nil then
				if (v.PARAM ~= "ipaddr" and v.PARAM ~= "netmask" and v.PARAM ~= "gateway" and v.PARAM ~= "dhcp_option")
					 or (dhcp_status == "0" and v.PARAM == "dhcp_option")
					 or (lan_type == "static" and (v.PARAM == "ipaddr" or v.PARAM == "netmask" or v.PARAM == "gateway"))
				then
					local cfg_name = v.MODULE .. "_" .. v.PARAM
					uci_r:set("sysmode", "ap", cfg_name, value)
				end
			end
		end
		wan_device_mac_change(false)
		uci_r:commit_without_write_flash("sysmode")

		for _,v in pairs(ROUTER_CFG) do
			local cfg_name,value
			if v.TYPE == "reverse" then
				cfg_name = v.MODULE .. "_" .. v.SECTION
				value = uci_r:get("sysmode", "router", cfg_name)
				if value ~= nil then
					uci_r:set(v.MODULE, v.SECTION, v.PARAM, value)
					uci_r:commit_without_write_flash(v.MODULE)
				end
			end
		end

		local form = {}
		form.form = "guest"
		form.operation = "write"
		form.isolate = uci_r:get("sysmode", "router", "isolate")
		form.access = uci_r:get("sysmode", "router", "access")
		wireless.wireless_predefined_forms(form, true)
	end

	return true
end
-- <<< change UCI config end

-- General controller routines

local dispatch_tbl = {
    logout = {
        [".super"] = {cb = logout}
    },
    reboot = {
        [".super"] = {cb = reboot}
    },
    sysmode = {
        [".super"] = {cb = sysmode}
    },
    change_ip = {
        [".super"] = {cb = change_IP}
    },
    kickoff_web = {
        ["kick"] = {cb = kickoff_web}
    }
}

function dispatch(http_form)
    return ctl.dispatch(dispatch_tbl, http_form)
end

function _index()
    return ctl._index(dispatch)
end

function index()
    entry({"admin", "system"}, call("_index")).leaf = true
end
