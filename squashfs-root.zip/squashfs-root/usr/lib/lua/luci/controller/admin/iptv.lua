--[[
Copyright(c) 2008-2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  iptv.lua
Details :  Controller for IPTV webpage
Author  :  Guo Dongxian <guodongxian@tp-link.net>
Version :  1.0.0
Date    :  12 Aug, 2014
]]--

module("luci.controller.admin.iptv", package.seeall)

local uci    = require "luci.model.uci"
local dtypes = require "luci.tools.datatypes"
local dbg    = require "luci.tools.debug"
local sys    = require "luci.sys"
local ctl    = require "luci.model.controller"  
local nixio  = require "nixio"

local RELOAD_IPTV = "/etc/init.d/iptv restart"
local cfg_changed = false

local RELOAD_IMPROXY = "/etc/init.d/improxy restart"
local RELOAD_UDPXY = "/etc/init.d/udpxy restart"

local improxy_changed = false
local udpxy_changed = false
local iptv_changed = false

local function profile_get()
    local uci_r = uci.cursor()
    return uci_r:get_profile("iptv", "mode")
end

local function dftmodes()
    return function(modes, i)
        i = i + 1
        local m = modes[i]
        if m then
            -- mode:internet_vid:internet_vprio:ipphone_vid:ipphone_vprio:iptv_vid:iptv_vprio:
            -- mciptv_vid:mciptv_vprio:internet_tag:mciptv_enable:lan1:lan2:lan3:lan4
            -- values: -1 for UI hide 
            local c, nid, npri, phid, phpri, tvid, tvpri, mcid, mcpri, ntag, mtag, l1, l2, l3, l4 = m:match("(.+):([-]?[0-9]+):([-]?[0-7]):([-]?[0-9]+):([-]?[0-7]):([-]?[0-9]+):([-]?[0-7]):([-]?[0-9]+):([-]?[0-7]):([-]?[0-1]):([-]?[0-1]):([1-3]):([1-3]):([1-3]):([1-3])")
            return i, c, nid, npri, phid, phpri, tvid, tvpri, mcid, mcpri, ntag, mtag, l1, l2, l3, l4
        end
    end, profile_get(), 0

end

local function get_dftmodes()
    local data = {}
    
    local function lan_type(c)
        -- 1 for Internet, 2 for IP-Phone, 3 for IPTV
        if c == 2 then return "IP-Phone"
        elseif c == 3 then return "IPTV"
        else return "Internet"
        end
    end

    for _, c, nid, npri, phid, phpri, tvid, tvpri, mcid, mcpri, ntag, mtag, l1, l2, l3, l4 in dftmodes() do
        data[#data + 1] = {
            mode = c,
            internet_vid   = nid,
            internet_vprio = npri,
            ipphone_vid = phid,
            ipphone_vprio = phpri,
            iptv_vid = tvid,
            iptv_vprio = tvpri,
            mciptv_vid = mcid,
            mciptv_vprio = mcpri,
            internet_tag = ntag,
            mciptv_enable = mtag,
            lan1 = lan_type(type(l1) == "string" and tonumber(l1)),
            lan2 = lan_type(type(l2) == "string" and tonumber(l2)),
            lan3 = lan_type(type(l3) == "string" and tonumber(l3)),
            lan4 = lan_type(type(l4) == "string" and tonumber(l4))
        }
    end
    return data
end

local function uci_get()
    local uci_r = uci.cursor()

    local function _get_iptv(u, opt)
        return u:get("iptv", "iptv", opt)    
    end
    local data = {
        enable = _get_iptv(uci_r, "enable"),
        mode   = _get_iptv(uci_r, "mode"),
        internet_tag   = _get_iptv(uci_r, "internet_tag"),
        internet_vid   = _get_iptv(uci_r, "internet_vid"),
        internet_vprio = _get_iptv(uci_r, "internet_vprio"),
        ipphone_vid    = _get_iptv(uci_r, "ipphone_vid"),
        ipphone_vprio  = _get_iptv(uci_r, "ipphone_vprio"),
        iptv_vid   = _get_iptv(uci_r, "iptv_vid"),
        iptv_vprio = _get_iptv(uci_r, "iptv_vprio"),
        mciptv_enable = _get_iptv(uci_r, "mciptv_enable"),
        mciptv_vid    = _get_iptv(uci_r, "mciptv_vid"),
        mciptv_vprio  = _get_iptv(uci_r, "mciptv_vprio"),
        lan_reversal_flag = _get_iptv(uci_r, "lan_reversal_flag"),
        lan1 = _get_iptv(uci_r, "lan1"),
        lan2 = _get_iptv(uci_r, "lan2"),
        lan3 = _get_iptv(uci_r, "lan3"),
        lan4 = _get_iptv(uci_r, "lan4"),
        igmp_snooping_enable = _get_iptv(uci_r, "igmp_snooping_enable"),
	udp_proxy = _get_iptv(uci_r, "udp_proxy") or "4022",
        igmp_enable = _get_iptv(uci_r, "igmp_enable"),
        udp_proxy_enable = _get_iptv(uci_r, "udp_proxy_enable") or "off",
        igmp_version = _get_iptv(uci_r, "igmp_version"),
        wait_time = _get_iptv(uci_r, "handle_time"),
        mcwifi_enable = _get_iptv(uci_r, "mcwifi_enable"),
        cfg_changed = cfg_changed,
        extinfo = get_dftmodes(),
        igmp_snooping_switch = uci_r:get_profile("iptv", "igmp_snooping_switch") or "no",
        udp_proxy_switch = uci_r:get_profile("iptv", "udp_proxy_switch") or "no",
        wlan_mcast_switch = uci_r:get_profile("iptv", "wlan_mcast_switch") or "no",
        qos_iptv_compatible = uci_r:get_profile("qos", "qos_iptv_compatible") or "no"

    }
    if data.lan_reversal_flag == "on" then
	data.lan1 = _get_iptv(uci_r, "lan4")
	data.lan2 = _get_iptv(uci_r, "lan3")
	data.lan3 = _get_iptv(uci_r, "lan2")
	data.lan4 = _get_iptv(uci_r, "lan1")
    end 

    return data
end

function set_network_attr()
    local iptv = uci_get()
    local uci_r = uci.cursor()

    local wtype = uci_r:get("network", "wan", "wan_type")
    if iptv.enable == "on" then
        if iptv.mode == "Bridge" then
            if iptv.lan1 == "IPTV" or iptv.lan2 == "IPTV"
                or iptv.lan3 == "IPTV" or iptv.lan4 == "IPTV"
            then
                uci_r:set("network", "wan", "type", "bridge")
                uci_r:set("network", "wan", "igmp_snooping", "1")
                
                if wtype == "pppoe" or wtype == "pppoeshare" or wtype == "pptp" or wtype == "l2tp" then          
                    uci_r:set("network", "internet", "ifname", "br-wan")                
                end
                uci_r:commit("network")
            end
        else
            local l3_ifname = uci_r:get("iptv", "iptv", "wan")
            local i = string.find(l3_ifname, '%.')
            local l3_dev = nil
            if i ~= nil then
                l3_dev = string.sub(l3_ifname, 0, i - 1)
            else
                l3_dev = l3_ifname
            end

            local lan_l3_ifname = uci_r:get("iptv", "iptv", "lan")
            local lan_l3_dev = nil
            i = string.find(lan_l3_ifname, '%.')
            if i ~= nil then
                lan_l3_dev = string.sub(lan_l3_ifname, 0, i - 1)
            else
                lan_l3_dev = lan_l3_ifname
            end

            local ifname = nil
            if iptv.internet_tag == "on" or lan_l3_dev == l3_dev then
                ifname = l3_dev .. "." .. iptv.internet_vid
            else
                ifname = l3_dev
            end
            uci_r:set("network", "wan", "ifname", ifname)
            if wtype == "pppoe" or wtype == "pppoeshare" or wtype == "pptp" or wtype == "l2tp" then              
                uci_r:set("network", "internet", "ifname", ifname)                
            end
            uci_r:commit("network")
        end        
    end
end

local function check(data)
    if not data or type(data) ~= "table" then
        return false
    end
    local uci_r = uci.cursor()
    local modetype = uci_r:get("iptv", "iptv", "mode")
    if data.mode == "none" then
        data.mode = modetype
    else
		if data.mode ~= "Bridge" and data.mode ~= "Custom"
			and data.mode ~= "Russia" and data.mode ~= "Maxis" and data.mode ~= "Maxis2"      
				and data.mode ~= "ExStream" and data.mode ~= "Unifi"
					and data.mode ~= "MEO" and data.mode ~= "VDF"
						and data.mode ~= "ufb" and data.mode ~= "nbn"
							and data.mode ~= "Vietnam"
		then
			return false
		end
	end

    if data.igmp_snooping_enable ~= "on" and data.igmp_snooping_enable ~= "off"
    then
        return false
    end

    if tonumber(data.udp_proxy) < 1024 or tonumber(data.udp_proxy) > 65535
    then
        return false
    end

    if data.udp_proxy_enable ~= "on" and data.udp_proxy_enable ~= "off"
    then
	    return false
    end

    if data.igmp_enable ~= "on" and data.igmp_enable ~= "off"
    then
	    return false
    end

    if data.mcwifi_enable ~= "on" and data.mcwifi_enable ~= "off"
    then
	    return false
    end

    if tonumber(data.igmp_version) < 2 or tonumber(data.igmp_version) > 3 then
        return false
    end

    local function _vid(vid)
        local uvid = tonumber(vid)
        if dtypes.integer(vid) and (uvid >= 0 and uvid <= 4094)
        then
            return true        
        end   
    end

    local function _prio(prio)
        local uprio = tonumber(prio)
        if dtypes.integer(prio) and (uprio >= 0 and uprio <= 7)
        then            
            return true        
        end    
    end

    local function _port_type(port, flag)
        local ptype = {}
        if flag then
            ptype = {"Internet", "IPTV", "IP-Phone", "Bridge"}
        else
            ptype = {"Internet", "IPTV"}
        end
        
        for _, k in ipairs(ptype) do
            if port == k then
                return true            
            end
        end
        return false
    end
    
    if not _vid(data.internet_vid) or not _prio(data.internet_vprio)
        or not _vid(data.iptv_vid) or not _prio(data.iptv_vprio)
            or not _vid(data.ipphone_vid) or not _prio(data.ipphone_vprio)
                or not _vid(data.mciptv_vid) or not _prio(data.mciptv_vprio)
    then
        return false    
    end

    local flag 
    if data.mode == "Custom" or data.mode == "Russia" or data.mode == "Maxis" or data.mode == "Maxis2" or data.mode == "MEO" or data.mode == "VDF" or data.mode == "Vietnam"
    then
        flag = true
    else
        flag = false
    end

    if not _port_type(data.lan1, flag) or not _port_type(data.lan2, flag)
        or not _port_type(data.lan3, flag) or not _port_type(data.lan4, flag)
    then
        return false
    end

    return true
end

local function parse_url(formvalue)
    local iptv_old = uci_get()
    local iptv_new = {
        -- igmp snooping
        igmp_snooping_enable = formvalue["igmp_snooping_enable"] or iptv_old.igmp_snooping_enable,
	--- udp proxy
	udp_proxy = formvalue["udp_proxy"] or iptv_old.udp_proxy,
	udp_proxy_enable = formvalue["udp_proxy_enable"] or iptv_old.udp_proxy_enable,
	-- igmp proxy
	igmp_enable = formvalue["igmp_enable"] or iptv_old.igmp_enable,
	igmp_version = formvalue["igmp_version"] or iptv_old.igmp_version,
        enable = formvalue["enable"] or iptv_old.enable,
        mode   = formvalue["mode"] or iptv_old.mode,
        -- wireless multicast
        mcwifi_enable = formvalue["mcwifi_enable"] or iptv_old.mcwifi_enable,
        -- internet
        internet_tag   = formvalue["internet_tag"] or iptv_old.internet_tag,
        internet_vid   = formvalue["internet_vid"] or iptv_old.internet_vid,
        internet_vprio = formvalue["internet_vprio"] or iptv_old.internet_vprio,
        -- ip-phone
        ipphone_vid    = formvalue["ipphone_vid"] or iptv_old.ipphone_vid,
        ipphone_vprio  = formvalue["ipphone_vprio"] or iptv_old.ipphone_vprio,
        -- iptv
        iptv_vid   = formvalue["iptv_vid"] or iptv_old.iptv_vid,
        iptv_vprio = formvalue["iptv_vprio"] or iptv_old.iptv_vprio,
        -- multicast iptv
        mciptv_enable = formvalue["mciptv_enable"] or iptv_old.mciptv_enable,
        mciptv_vid    = formvalue["mciptv_vid"] or iptv_old.mciptv_vid,
        mciptv_vprio  = formvalue["mciptv_vprio"] or iptv_old.mciptv_vprio,
	lan_reversal_flag = iptv_old.lan_reversal_flag,
        -- port type information
        lan1 = formvalue["lan1"] or iptv_old.lan1,
        lan2 = formvalue["lan2"] or iptv_old.lan2,
        lan3 = formvalue["lan3"] or iptv_old.lan3,
        lan4 = formvalue["lan4"] or iptv_old.lan4,

        -- igmp = formvalue["igmp"] or iptv_old.igmp
    }
	
    -- In quick_setup when disable iptv, mode = none, but nothing changed
    if iptv_new.mode == "none" then
		iptv_new.mode =  iptv_old.mode
	end
	

	if iptv_new.udp_proxy ~= iptv_old.udp_proxy or iptv_new.udp_proxy_enable ~= iptv_old.udp_proxy_enable then
		udpxy_changed = true
	end
	
	if iptv_new.igmp_enable ~= iptv_old.igmp_enable or iptv_new.igmp_version ~= iptv_old.igmp_version then
		improxy_changed = true
	end

	if iptv_new.igmp_snooping_enable ~= iptv_old.igmp_snooping_enable or iptv_new.mcwifi_enable ~= iptv_old.mcwifi_enable or iptv_new.enable ~= iptv_old.enable or iptv_new.mode ~= iptv_old.mode then
		iptv_changed = true
	elseif iptv_new.lan1 ~= iptv_old.lan1 or iptv_new.lan2 ~= iptv_old.lan2 or iptv_new.lan3 ~= iptv_old.lan3 or iptv_new.lan4 ~= iptv_old.lan4	then
		iptv_changed = true
	elseif iptv_new.mode == "Bridge" then	
		iptv_changed = false
	elseif	iptv_new.internet_tag ~= iptv_old.internet_tag
                    or iptv_new.internet_vid ~= iptv_old.internet_vid
                        or iptv_new.internet_vprio ~= iptv_old.internet_vprio
                            or iptv_new.ipphone_vid ~= iptv_old.ipphone_vid
                                or iptv_new.ipphone_vprio ~= iptv_old.ipphone_vprio
                                    or iptv_new.iptv_vid ~= iptv_old.iptv_vid
                                        or iptv_new.iptv_vprio ~= iptv_old.iptv_vprio
                                            or iptv_new.mciptv_enable ~= iptv_old.mciptv_enable
                                                or iptv_new.mciptv_vid ~= iptv_old.mciptv_vid
                                                    or iptv_new.mciptv_vprio ~= iptv_old.mciptv_vprio
														or iptv_new.iptv_tag ~= iptv_old.iptv_tag
															or iptv_new.ipphone_tag ~= iptv_old.ipphone_tag then
		
		iptv_changed = true
	end


	if iptv_changed == false and udpxy_changed == false and improxy_changed == false then
		return false, true  
	end
    
    if iptv_new.mode == "ExStream" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "10"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "20"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "4"
        
        iptv_new.lan1 = formvalue["lan1"] or "Internet"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "Internet"
        iptv_new.lan4 = formvalue["lan4"] or "IPTV" 
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"
    elseif iptv_new.mode == "Unifi" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "500"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "600"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"

        iptv_new.lan1 = formvalue["lan1"] or "IPTV"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "Internet"
        iptv_new.lan4 = formvalue["lan4"] or "Internet"
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"
    elseif iptv_new.mode == "Maxis" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "621"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "823"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"

        iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "821"
        iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
        -- Multicast IPTV Disabled
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"

        iptv_new.lan1 = formvalue["lan1"] or "IPTV"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "Internet"
        iptv_new.lan4 = formvalue["lan4"] or "IP-Phone" 
     elseif iptv_new.mode == "Maxis2" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "11"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "17"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"

        iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "821"
        iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
        -- Multicast IPTV Disabled
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"

        iptv_new.lan1 = formvalue["lan1"] or "IPTV"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "Internet"
        iptv_new.lan4 = formvalue["lan4"] or "IP-Phone"     
    elseif iptv_new.mode == "Russia" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "1257"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "4000"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "4"

        iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "263"
        iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"

        iptv_new.lan1 = formvalue["lan1"] or "IP-Phone"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "Internet"
        iptv_new.lan4 = formvalue["lan4"] or "IPTV"
    elseif iptv_new.mode == "Vietnam" then
		iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
		iptv_new.internet_vid   = formvalue["internet_vid"] or "35"
		iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"
		 
		iptv_new.iptv_vid   = formvalue["iptv_vid"] or "36"
		iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "4"
		 
		iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "37"
		iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "5"
		iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"
		 
		iptv_new.lan1 = formvalue["lan1"] or "Internet"
		iptv_new.lan2 = formvalue["lan2"] or "Internet"
		iptv_new.lan3 = formvalue["lan3"] or "IPTV"
		iptv_new.lan4 = formvalue["lan4"] or "IP-Phone"
    elseif iptv_new.mode == "MEO" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "12"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "0"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"

        iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "0"
        iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"

        iptv_new.lan1 = formvalue["lan1"] or "Internet"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "Internet"
        iptv_new.lan4 = formvalue["lan4"] or "Bridge"
    elseif iptv_new.mode == "VDF" then
        iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
        iptv_new.internet_vid   = formvalue["internet_vid"] or "100"
        iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"

        iptv_new.iptv_vid   = formvalue["iptv_vid"] or "105"
        iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"

        iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "101"
        iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
        iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"

        iptv_new.lan1 = formvalue["lan1"] or "Internet"
        iptv_new.lan2 = formvalue["lan2"] or "Internet"
        iptv_new.lan3 = formvalue["lan3"] or "IPTV"
        iptv_new.lan4 = formvalue["lan4"] or "Bridge"
	elseif iptv_new.mode == "nbn" then
		iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
		iptv_new.internet_vid   = formvalue["internet_vid"] or "100"
		iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"
		            
		iptv_new.iptv_vid   = formvalue["iptv_vid"] or "0"
		iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"
		            
		iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "0"
		iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
		iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"
		          
		iptv_new.lan1 = formvalue["lan1"] or "Internet"
		iptv_new.lan2 = formvalue["lan2"] or "Internet"
		iptv_new.lan3 = formvalue["lan3"] or "Internet"
		iptv_new.lan4 = formvalue["lan4"] or "Internet"
	elseif iptv_new.mode == "ufb" then
		iptv_new.internet_tag   = formvalue["internet_tag"] or "on"
		iptv_new.internet_vid   = formvalue["internet_vid"] or "10"
		iptv_new.internet_vprio = formvalue["internet_vprio"] or "0"
		            
		iptv_new.iptv_vid   = formvalue["iptv_vid"] or "0"
		iptv_new.iptv_vprio = formvalue["iptv_vprio"] or "0"
		            
		iptv_new.ipphone_vid = formvalue["ipphone_vid"] or "0"
		iptv_new.ipphone_vprio = formvalue["ipphone_vprio"] or "0"
		iptv_new.mciptv_enable = formvalue["mciptv_enable"] or "off"
		            
		iptv_new.lan1 = formvalue["lan1"] or "Internet"
		iptv_new.lan2 = formvalue["lan2"] or "Internet"
		iptv_new.lan3 = formvalue["lan3"] or "Internet"
		iptv_new.lan4 = formvalue["lan4"] or "Internet"		
    end


    if not check(iptv_new) then
        return false, false
    end

    return iptv_new
end

local function get()
    return uci_get()
end

local function set(formvalue)
    local save, err = parse_url(formvalue)
    
    if not save and not err then
        return false, "Invalid URL"
    end

    if save then
        local uci_r = uci.cursor()
        local log = require("luci.model.log").Log(216)
        if save.enable == "on" then
            log(502)
        else
            log(503)
        end
        cfg_changed = true

	-- sleep 2s if wan is also changed in quick-setup!
        nixio.nanosleep(2, 0)

        -- Set igmp snooping
        uci_r:set("iptv", "iptv", "igmp_snooping_enable", save.igmp_snooping_enable)

	--- Set udp proxy
        uci_r:set("iptv", "iptv", "udp_proxy", save.udp_proxy)
        uci_r:set("iptv", "iptv", "udp_proxy_enable", save.udp_proxy_enable)

        -- Set igmp proxy
        uci_r:set("iptv", "iptv", "igmp_enable", save.igmp_enable)
        uci_r:set("iptv", "iptv", "igmp_version", save.igmp_version)
        uci_r:set("iptv", "iptv", "mcwifi_enable", save.mcwifi_enable)

        uci_r:set("iptv", "iptv", "enable", save.enable)
        uci_r:set("iptv", "iptv", "mode",   save.mode)
        uci_r:set("iptv", "iptv", "internet_tag",   save.internet_tag)
        uci_r:set("iptv", "iptv", "internet_vid",   save.internet_vid)
        uci_r:set("iptv", "iptv", "internet_vprio", save.internet_vprio)
        uci_r:set("iptv", "iptv", "ipphone_vid",    save.ipphone_vid)
        uci_r:set("iptv", "iptv", "ipphone_vprio",  save.ipphone_vprio)
        uci_r:set("iptv", "iptv", "iptv_vid",   save.iptv_vid)
        uci_r:set("iptv", "iptv", "iptv_vprio", save.iptv_vprio)
        uci_r:set("iptv", "iptv", "mciptv_enable", save.mciptv_enable)
        uci_r:set("iptv", "iptv", "mciptv_vid",    save.mciptv_vid)
        uci_r:set("iptv", "iptv", "mciptv_vprio",  save.mciptv_vprio)
	if  save.lan_reversal_flag == "on" then
		uci_r:set("iptv", "iptv", "lan4", save.lan1)
		uci_r:set("iptv", "iptv", "lan3", save.lan2)
		uci_r:set("iptv", "iptv", "lan2", save.lan3)
		uci_r:set("iptv", "iptv", "lan1", save.lan4)
	else
        uci_r:set("iptv", "iptv", "lan1", save.lan1)
        uci_r:set("iptv", "iptv", "lan2", save.lan2)
        uci_r:set("iptv", "iptv", "lan3", save.lan3)
        uci_r:set("iptv", "iptv", "lan4", save.lan4)
	end
        uci_r:commit("iptv")
        
		if iptv_changed == true then
			sys.fork_exec(RELOAD_IPTV)
		else
			
			if udpxy_changed == true then
				sys.fork_exec(RELOAD_UDPXY)
			end
			if improxy_changed == true then
				sys.fork_exec(RELOAD_IMPROXY)
			end
		end
    end
    
    return uci_get()
end

local dispatch_tbl = {
    ["setting"] = {
        ["read"]  = { cb = get },
        ["write"] = { cb = set }
    }
}

function dispatch(http_form)
    return ctl.dispatch(dispatch_tbl, http_form)
end

function _index()
    return ctl._index(dispatch)
end

function index()
    entry({"admin", "iptv"}, call("_index")).leaf = true
end

