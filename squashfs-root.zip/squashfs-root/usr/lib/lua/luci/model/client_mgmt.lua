--[[
Copyright(c) 2008-2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  client_mgmt.lua
Details :  Ubus client for client management.
Author  :  Ye Qianchuan <yeqianchuan@tp-link.net>
Author  :  Jin Xuexue <jinxuexue@tp-link.net>
Version :  1.0.0
Date    :  07 Mar, 2014
]]--

module ("luci.model.client_mgmt", package.seeall)

local ubus  = require "ubus"
local sys   = require "luci.sys"
local uci   = require "luci.model.uci"
local uci_r = uci.cursor()
local _ubus
local _clist

local UBUS_OBJECT = "client_mgmt"

--- Connect ubus for getting data later.
function init()
    _ubus = ubus.connect()
end

--- Refresh clients table.
-- @return        Boolean whether operation succeeded
function update()
    _ubus = _ubus or ubus.connect()
	if _ubus == nil then
		return false
	else
		_ubus:call(UBUS_OBJECT, "update", {})
		return true
	end
end

--- Get the ARP table.
-- @return        Table of ARP
function get_ARP()
    _ubus = _ubus or ubus.connect()
	if _ubus == nil then
		return nil
	else
		return _ubus:call(UBUS_OBJECT, "get_ARP", {})
	end
end

--- Get the list of clients.
-- @return        Table of client entries
function get_client_list()
    _ubus = _ubus or ubus.connect()
	if _ubus == nil then
		return nil
	else
		_ubus:call(UBUS_OBJECT, "update", {})
		_clist = _clist or _ubus:call(UBUS_OBJECT, "get", {request_type=0})
        for i=1,#_clist do
            _clist[i].hostname = match_history_list(_clist[i].mac) or _clist[i].hostname
        end
		return _clist
	end
end

--- Get the list of clients with ip mixed and enter.
-- @return        Table of client entries
function get_client_list_dev()
    local _ubus = _ubus or ubus.connect()
    if _ubus == nil then
    	return nil
    end
	
    _clist = _clist or _ubus:call(UBUS_OBJECT, "get", {request_type=0}) or {}
    local clist = _clist

    for _, client in ipairs(clist) do
        local mac = client.mac
        if mac then
            for _ , client_cmp in ipairs(clist) do
                if client ~= client_cmp and client_cmp.mac == mac then
                    client_cmp.mac = nil
                    client.ip = client.ip .. "<br />" .. client_cmp.ip
                    if client.hostname ~= client_cmp.hostname and client.hostname == "UNKNOW" then
                        client.hostname = client_cmp.hostname
                    end
                end  
            end
        end
    end
    
    for index, client in ipairs(clist) do 
        if client.mac == nil then
            clist[index] = nil
        end
    end

    return clist
end

--- Get the history list.
-- @return		Table of client entries
function get_history_list_dev(type)
	type = type or 0
    local _ubus = _ubus or ubus.connect()
    return _ubus:call(UBUS_OBJECT, "get_hist_list", {request_type=type})    
end

--- Get the list of clients subjected to the given filter.
-- @param field            Key to be filtered by
-- @param cmp            Value to be compared with
-- @param need_update    Update first if true (optional)
-- @return                Table of client entries filtered
function get_client_by(field, cmp, need_update)
    if need_update then
        update()
    end

    local clist = get_client_list()
    if not clist then
        return
    end

    for _, client in ipairs(clist) do
        if client[field] == cmp then
            return client
        end
    end
end

--- Get Mac address by given IP address.
-- @param ipaddr        IP address to be compared with
function get_mac_by_ip(ipaddr)
    local arp = get_ARP() or {}
    for _, item in pairs(arp) do
        if item.ip == ipaddr then
            return item.mac
        end
    end
	return nil
end

function set_client_nickname(dev_mac, nick_name)
    local _ubus = _ubus or ubus.connect()
    _ubus:call(UBUS_OBJECT, "set_dev_nickname", {nickname=nick_name,device_mac=dev_mac})
end

function set_client_devtype(dev_mac, dev_type)
    local _ubus = _ubus or ubus.connect()
    _ubus:call(UBUS_OBJECT, "set_dev_type", {device_type=dev_type,device_mac=dev_mac})
end

function match_history_list(mac)
    local table = uci_r:get_all("history_list")
    for k, client in pairs(table) do
            if client.mac == mac:gsub("-", ""):upper() then
                return client.nickname
            end
    end
    return nil
end
--[[
-- The format of one client entry is as follow:
    {
        hostname    = "name"
        ip             = "192.168.1.241"
        mac         = "00-11-22-33-44-55"
        wire_type    = "wired/2.4G/5G/UNKNOW"
        guest         = "GUEST/NON_GUEST/UNKNOW"
        active        = 0/1
    }
]]--
