--[[
Copyright(c) 2008-2014 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  tm_clientmgmt.lua
Details :  Ubus and uci client for client management.
Author  :  Ye Qianchuan <yeqianchuan@tp-link.net>
Author  :  Jin Xuexue <jinxuexue@tp-link.net>
Author  :  Wang Lian <wanglian@tp-link.net>
Version :  1.0.1
Date    :  15July, 2016
History :  \arg 1.0.1, 04July, 2016
           \arg 1.0.0, 07 Mar, 2014
]]--

module ("luci.model.tm_clientmgmt", package.seeall)

local sys    = require "luci.sys"
local dbg    = require "luci.tools.debug"
local uci    = require "luci.model.uci"
local json   = require "luci.json"
local ubus   = require "ubus"
local _ubus

local UBUS_OBJECT = "client_mgmt"

local uci_s = uci.cursor()  

local CLIENT_TYPE_TBL = {
    ["0"] = "other",
    ["1"] = "pc",
    ["2"] = "phone",
    ["3"] = "laptop",
    ["4"] = "tablet",
    ["5"] = "entertainment",
    ["6"] = "printer",
    ["7"] = "iot_device"
}
local PROC_DEVICES = "/proc/pctl/devices"

local function TrimStr(str)
    local tmpstr = str
	tmpstr = string.gsub(tmpstr, "-", "")
    str = string.match(tmpstr, "%w+")
    str = str:upper()
    return str
end


--- Connect ubus for getting data later.
function init()
	_ubus = ubus.connect()
end

--- Get the list of clients with ip mixed and enter.
-- @return		Table of client entries
function get_client_list_qos()
    local _ubus = _ubus or ubus.connect()
    local clist = _ubus:call(UBUS_OBJECT, "get_hist_list", {request_type=1})

    local res = {}
    for _, client in ipairs(clist) do
        local mac = client.mac
        if mac then
            for _ , client_cmp in ipairs(clist) do
                if client ~= client_cmp and client_cmp.mac == mac then
                    client_cmp.mac = nil
                    if client.hostname ~= client_cmp.hostname and client.hostname == "UNKNOWN" then
                        client.hostname = client_cmp.hostname
                    end
                end  
            end

        end
    
        if client.mac then
            -- FIXME: remove inactive clients
            -- remove clients in black list
            local client_mac = TrimStr(client.mac)
            local blk_cli = uci_s:get_all("blacklist", client_mac) 
            if blk_cli then
                client.mac = nil
            end
        end

        if client.mac then
            res[#res + 1] = client
        end
    end

    return res
end

local function get_user_mac()
    -- get user ipaddr from uhttpd
    local user_ip  = sys.getenv("REMOTE_ADDR")
    local user_mac = ""

    -- get user_mac from arp table by user_ip
    for _, v in ipairs(luci.sys.net.arptable()) do
        if user_ip and user_ip == v["IP address"] then
            user_mac = v["HW address"]
            break
        end
    end

    return user_mac
end


local function get_list( list_type )
    local list = {}
    local uci_r = uci.cursor()
	local user_mac = get_user_mac():gsub("-", ":"):upper()
    uci_r:foreach("access_control", list_type,
        function(section)
            list[#list + 1] = uci_r:get_all("access_control", section[".name"])
            list[#list].mac = (list[#list].mac):gsub(":", "-"):upper()
            list[#list].host = (list[#list].mac == user_mac:gsub(":", "-"):upper()) and "HOST" or "NON_HOST"
        end
    )
    return list
end
--- Get the list of clients with ip mixed and enter.
-- @return		Table of client entries
function get_client_list_dev()
    local _ubus = _ubus or ubus.connect()

    if _ubus == nil then
        return {}
    end

    local clist = _ubus:call(UBUS_OBJECT, "get_hist_list", {request_type=0})
    local clist_online = _ubus:call(UBUS_OBJECT, "get_hist_list", {request_type=1})
    local black_list  = get_list("black_list")


    local res = {}
    for _, client in ipairs(clist) do
        local mac = client.mac
        if mac then
            for _ , client_cmp in ipairs(clist) do
                if client ~= client_cmp and client_cmp.mac == mac then
                    client_cmp.mac = nil
                    if client.hostname ~= client_cmp.hostname and client.hostname == "UNKNOWN" then
                        client.hostname = client_cmp.hostname
                    end
                end  
            end

        end
    
        if client.mac then
            -- FIXME: remove inactive clients
            -- remove clients in black list
            local client_mac = TrimStr(client.mac)
            local blk_cli = uci_s:get_all("blacklist", client_mac) 
            if blk_cli then
                client.mac = nil
            end
        end
		
		client.online = 0 
		
		for _, client1 in ipairs(clist_online) do
			if client.mac == client1.mac then
				client.online = 1
			end
		end
		for _, black in ipairs(black_list) do
			if black.mac == client.mac  then 
				client.online = 0 
			end
		end
        if client.mac then
            res[#res + 1] = client
        end
    end

    return res
end

local function get_max_client()    
    local max_num = uci_s:get_profile("client_mgmt", "max_dev") or "64"
    return max_num
end

local function comps(a, b)
    return tonumber(a.access_time) < tonumber(b.access_time)
end

----------------user set---------------------------

local function store_client_info(client, need_commit)
    local max_num = get_max_client()

    local clist_u = {}

    -- 1. check client num
    uci_s:foreach("client_mgmt", "client",
        function(section)               
            local cli = section
            --if cli.usr_set ~= nil then                
                clist_u[#clist_u + 1] = cli
            --end
        end
    )   

    -- 2. if exceeds max_num, delete one
    if (#clist_u) >= tonumber(max_num) then
            table.sort(clist_u, comps) 
            local cli = clist_u[1]
        uci_s:delete("client_mgmt", cli[".name"])        
        end

    -- 3. set
    local client_mac = TrimStr(client.mac)
    uci_s:section("client_mgmt", "client", client_mac, client)

    -- 4. commit
    local stat = true
    if need_commit ~= nil and need_commit == true or need_commit == nil then
        stat = uci_s:commit("client_mgmt")
    end

    return stat
end

function set_client_info(client)
    -- 1. if in config, set
    local found = false
    uci_s:foreach("client_mgmt", "client",
        function(section)               
            if not found and client.mac == section.mac then
                found = true                   
                uci_s:section("client_mgmt", "client", section[".name"], client)             
            end
        end
    )   

    if found then
        local stat = uci_s:commit("client_mgmt")
        return stat
    end

    -- 2. else try to store
    local ret = store_client_info(client)    

   return ret
end

function batch_set_client_info(client_list)
    
    local found = false
    for k,client in pairs(client_list) do
        found = false
		uci_s:foreach("client_mgmt", "client",
            function(section)               
				if not found and client.mac == section.mac then
                    found = true
                    uci_s:section("client_mgmt", "client", section[".name"], client)          
                end
            end
        )   

        if not found then
            store_client_info(client, false)
        end
    end

    return uci_s:commit("client_mgmt")
end


function remove_client_list_for(owner_id)
	local now = os.time()
	local fg_changed = 0
    uci_s:foreach("client_mgmt", "client",
		function(section)  
			if owner_id == section.owner_id then
				if section.prio_time == nil or tonumber(section.prio_time) ~= -1 and tonumber(section.prio_time) < now then
					uci_s:delete("client_mgmt", section[".name"])
				else
					uci_s:set("client_mgmt", section[".name"], "owner_id", "")
				end
				fg_changed = 1
			end
        end
    )   
    
    if fg_changed == 1 then
    	return uci_s:commit("client_mgmt")
    end	
end

function get_client_list_by(owner_id)
	local client_list = {}
	uci_s:foreach("client_mgmt", "client",
		function(section)
			if section.owner_id == owner_id then
				local client = {}
				client.device_id = section[".name"]
				client.owner_id = section.owner_id
				client.mac = section.mac
				client.client_type = section.type
				client.name = section.name
				client_list[#client_list + 1] = client
			end
		end
    )
	return client_list
end


----------------access_handle-------------------
local TEMP_UCI_PATH = "/tmp/tmp-device-config"
local uci_t = uci.cursor(TEMP_UCI_PATH) 

-- get client type form trend micro
function get_client_type_list()
    local deviceMap = {}
    local f = io.open(PROC_DEVICES,"r")
    if f then
        for line in f:lines() do
			--dbg.print("line="..line)
            device_mac, device_type = string.match(line, "([^,;]+) (%d+)")
			--dbg.print(device_mac, device_type)
            deviceMap[device_mac] = device_type;
        end
		f:close()
	else
		dbg.print("open "..PROC_DEVICES.."failed.\n")	
    end

    return deviceMap
end

function get_client_type(mac, deviceMap)
    local t = deviceMap[mac]
    if t ~= nil then
        return CLIENT_TYPE_TBL[t];
    else
        return "other"
    end
end

-- get all clients (online and offline)
function get_access_client_list_qos()
    local client_list = {}
    local client_found = {}

    --local history_list = get_client_list_qos()
    local history_list = get_client_list_dev()
    local cur_time = os.time()
    
    local deviceMap = get_client_type_list()
	
    for i, v in ipairs(history_list) do
		local client = {}
		client.device_id = TrimStr(v.mac)
		--client.ip = v.ip
		client.mac = v.mac
		--cliient.name = v.hostname
		--client.client_type = get_client_type(v.mac, deviceMap)
		client.name = uci_s:get("client_mgmt", TrimStr(v.mac), "name") or v.hostname
		client.client_type =  uci_s:get("client_mgmt", TrimStr(v.mac), "type") or get_client_type(v.mac, deviceMap) 
		client.wire_type =  v.wire_type
		client.guest = v.guest or ""
		client.online = v.online
		client.owner_id = tonumber(uci_s:get("client_mgmt", client.device_id, "owner_id")) or -1
		client.access_time = uci_s:get("client_mgmt", client.device_id, "access_time") or  v.access_time 
		client.prio = uci_s:get("client_mgmt", client.device_id, "prio") or "off" 
		client.prio_time = uci_s:get("client_mgmt", client.device_id, "prio_time") or ""
		client.time_period = uci_s:get("client_mgmt", client.device_id, "time_period") or "-1"
		client.owner_name = uci_s:get("parental_control_v2", tostring(client.owner_id), "name") or ""
		client_list[#client_list + 1] = client
		client_found[client.device_id] = "true"
    end

	uci_s:foreach("client_mgmt", "client",
        function(section)               
            if client_found[TrimStr(section.mac)] ~= "true" and section.prio == "on" then
				local client = {}
                client.device_id = TrimStr(section.mac)
				--client.ip = section.ip
				client.mac = section.mac
				client.name = section.name
				client.client_type = section.type
				client.guest = section.guest or ""
				client.wire_type = "offline"
				--client.online = section.wire_type == "UNKNOW" and 0 or 1
				client.online = 0 
				client.access_time = section.access_time
				client.owner_id = tonumber(section.owner_id) or -1
				client.owner_name = uci_s:get("parental_control_v2", section.owner_id or "", "name") or ""
				client.prio = section.prio or "off" 
				client.prio_time = section.prio_time or ""
				client.time_period = section.time_period or "-1"
				client_list[#client_list + 1] = client
            end
        end
    )
	
	

    return client_list
end


-- get all clients (online and offline)
function get_access_client_list()
    local client_list = {}
    local client_found = {}

    local history_list = get_client_list_dev()
    local cur_time = os.time()
    
    local deviceMap = get_client_type_list()

    for i, v in ipairs(history_list) do
		local client = {}
		client.device_id = TrimStr(v.mac)
		--client.ip = v.ip
		client.mac = v.mac
		--client.name = v.hostname
		--client.client_type = get_client_type(v.mac, deviceMap)
		client.name = uci_s:get("client_mgmt", TrimStr(v.mac), "name") or v.hostname
		client.client_type =  uci_s:get("client_mgmt", TrimStr(v.mac), "type") or get_client_type(v.mac, deviceMap) 
		client.owner_id = tonumber(uci_s:get("client_mgmt", client.device_id, "owner_id")) or ""
        client.prio = uci_s:get("client_mgmt", client.device_id, "prio") or "off" 
        client.prio_time = uci_s:get("client_mgmt", client.device_id, "prio_time") or ""
        client.time_period = uci_s:get("client_mgmt", client.device_id, "time_period") or "-1"
		client_list[#client_list + 1] = client
		client_found[client.device_id] = "true"
    end

	uci_s:foreach("client_mgmt", "client",
        function(section)               
            if client_found[TrimStr(section.mac)] ~= "true" then
				local client = {}
                client.device_id = TrimStr(section.mac)
				--client.ip = section.ip
				client.mac = section.mac
				client.name = section.name
				client.client_type = section.type
				client.owner_id = tonumber(section.owner_id) or ""
                client.prio = section.prio or "off" 
                client.prio_time = section.prio_time or ""
                client.time_period = section.time_period or "-1"
				client_list[#client_list + 1] = client
            end
        end
    )
	
    return client_list
end

function client_house_keeping()
    local now = os.time()
    local fg_changed = 0
	
    -- del invaild client
    uci_s:foreach("client_mgmt", "client",
        function(section)
            local client = section
                       
            -- for client from parent control setting,there is no prio* settings at all!
            if client.prio == nil and client.prio_time == nil and client.time_period == nil then
                return
            end
                        
        		if client.prio_time == nil or tonumber(client.prio_time) ~= -1 and tonumber(client.prio_time) < now then
								if client.owner_id == nil then
					        uci_s:delete("client_mgmt", client[".name"])
					        fg_changed = 1
								else
									uci_s:set("client_mgmt", client[".name"], "time_period", "")
									uci_s:set("client_mgmt", client[".name"], "prio", "")
									uci_s:set("client_mgmt", client[".name"], "prio_time", "")
									fg_changed = 1
								end
            end
        end
    ) 
    if fg_changed == 1 then
    	uci_s:commit("client_mgmt")
    end
end

function remove_client_list(owner_id, client_list)
	local now = os.time()
	local fg_changed = 0
	
	if client_list then
		for i,v in ipairs(client_list) do
			local name = TrimStr(v)
			local l_owner_id = uci_s:get("client_mgmt", name, "owner_id")
			local l_prio_time = uci_s:get("client_mgmt", name, "prio_time")
			if owner_id == tonumber(l_owner_id) then
				if l_prio_time == nil or tonumber(l_prio_time) ~= -1 and tonumber(l_prio_time) < now then
					uci_s:delete("client_mgmt", name)
				else
					uci_s:set("client_mgmt", name, "owner_id", "")
				end
				fg_changed = 1
			end
		end
		
		if fg_changed == 1 then
			uci_s:commit("client_mgmt")
		end	
	end
end

-------- tether -----
function get_ARP()
    _ubus = _ubus or ubus.connect()
    if _ubus == nil then
        return nil
    else
        return _ubus:call(UBUS_OBJECT, "get_ARP", {})
    end
end

function get_ip_by_mac(mac)
    local arp = get_ARP() or {}
    for _, item in pairs(arp) do
        if item.mac == mac then
            return item.ip
        end
    end
    return nil
end

