--[[
Copyright(c) 2008-2016 Shenzhen TP-LINK Technologies Co.Ltd.

File    :  qos.lua
Details :  qos for application and device priority
Author  :  Zhu Junjie <zhujunjie@tp-link.net>
Version :  1.0.0
Date    :  8 Nov, 2016
]]--

module("luci.model.qos_v2", package.seeall)

local string = require "string"
local sys    = require "luci.sys"
local io	 = require "io"
local util   = require "luci.util"
local uci    = require "luci.model.uci"
local dbg    = require "luci.tools.debug"
local clientmgmt = require "luci.model.tm_clientmgmt"
local tfs        = require "luci.model.tfstats"
local nat_m = require "luci.model.nat"
local Nat = nat_m.NAT_INST()

local QOS_RESTART_CMD = "/etc/init.d/qos restart &"
local QOS_CONFIG_NAME = "qos_v2"

local CONN_TYPE_TBL = {
	["wired"] = "wired",
	["2.4G"] = "wls_2_4g",
	["5G"] = "wls_5g",
	["2.4G_guest"] = "wls_2_4g_guest",
	["5G_guest"] = "wls_5g_guest"
}

local function getConnType(client)
    local ret 
    local wireType = client.wire_type
    local guest = client.guest or ""
    
    if guest == "GUEST" then
        if wireType == "2.4G" then
            ret = CONN_TYPE_TBL["2.4G_guest"]
        else
            ret = CONN_TYPE_TBL["5G_guest"]
        end
    else
         ret = CONN_TYPE_TBL[wireType]
    end
    
    return  ret 
end

-- Debug console output method.
-- @param    str    String to display on console.
-- @return N/A
function printf(str)
    if str then
        os.execute("echo %q &>/dev/console" % (str))
    end
end

local function _print_tbl(data)
    if type(data) == "table" then
        for i, v in pairs(data) do
            dbg.print(i .. " = " .. tostring(data[i]))
            if type(data[i]) == "table" then
                _print_tbl(data[i])
            end
        end
    end
end

QOS_INST = util.class()
function QOS_INST:__init__()
    self.config = QOS_CONFIG_NAME
    self.uci = uci.cursor()
end

function QOS_INST:get_settings()
    local ret = {}
	
    ret.enable    = self.uci:get(QOS_CONFIG_NAME, "settings", "enable") or "off"
    ret.up_band   = self.uci:get(QOS_CONFIG_NAME, "settings", "up_band") or ""
    ret.down_band = self.uci:get(QOS_CONFIG_NAME, "settings", "down_band") or ""
    ret.up_unit   = self.uci:get(QOS_CONFIG_NAME, "settings", "up_unit") or "kbps"
    ret.down_unit = self.uci:get(QOS_CONFIG_NAME, "settings", "down_unit") or "kbps"
    ret.high      = self.uci:get(QOS_CONFIG_NAME, "settings", "high") or "60"
    ret.middle    = self.uci:get(QOS_CONFIG_NAME, "settings", "middle") or "30"
    ret.low       = self.uci:get(QOS_CONFIG_NAME, "settings", "low") or "10"
    ret.time      = self.uci:get(QOS_CONFIG_NAME, "settings", "time") or "10"
    ret.enable_phy= self.uci:get_profile(QOS_CONFIG_NAME, "by_phy") ~= 0 and "on" or "off"
    ret.enable_app= self.uci:get_profile(QOS_CONFIG_NAME, "by_app") ~= 0 and "on" or "off"
    ret.qos_iptv_compatible = self.uci:get_profile(QOS_CONFIG_NAME, "qos_iptv_compatible") or "no"
    ret.max_wan_speed = self.uci:get_profile(QOS_CONFIG_NAME, "max_wan_speed") or "100"
    return ret
end

function QOS_INST:set_settings(form)
    local ret = {}
    local settings = {"enable", "up_band", "down_band", "up_unit", "down_unit", "high", "middle", "low"}
	local qos_enable
   
    for _, set in ipairs(settings) do
        local val = form[set]
		if "enable" == set then
			qos_enable = val
		end
        if val ~= nil then
             self.uci:set(QOS_CONFIG_NAME, "settings", set, val)
        end
    end
	
	local upband = tonumber(form["up_band"])
	local downband = tonumber(form["down_band"])
	local realUpband = upband
	local realDownband = downband
	
	if(form["up_unit"] == "mbps") then
		realUpband = math.floor(upband * 1000)
	else
		realUpband = math.floor(upband * 1.0)
	end
	if(form["down_unit"] == "mbps") then
		realDownband = math.floor(downband * 1000)
	else
		realDownband = math.floor(downband * 1.0)
	end
	
	self.uci:set(QOS_CONFIG_NAME, "settings", "rUpband", realUpband)
	self.uci:set(QOS_CONFIG_NAME, "settings", "rDownband", realDownband)

    self.uci:commit(QOS_CONFIG_NAME)
	sys.fork_exec(QOS_RESTART_CMD)
	
	-- sync traffic_statistics config
	local tfs = require "luci.model.tfstats"
	local tfs_t = tfs.TFS_INST()
	local tfs_enable
	if "on" == qos_enable then -- qos_enable is 'on', then off NAT_Boost and on traffic_statistics
		-- enable traffic_statistics
		tfs_enable = "on"
		tfs_t:set_enable(tfs_enable)
	else -- qos_enable is 'off', then on NAT_Boost and off traffic_statistics
		-- disable traffic_statistics
		tfs_enable = "off"
		tfs_t:set_enable(tfs_enable)
	end
	
	-- sync HNAT
	Nat:sync_hnat_status()
	
    return {}
end

local function sort_devlist(dev_list)
    table.sort(dev_list, function(a,b)
        return (a.deviceName < b.deviceName)
    end)
end

local function TrimStr(str)
    local tmpstr = str
    tmpstr = string.gsub(tmpstr, "-", "")
	tmpstr = string.gsub(tmpstr, ":", "")
    str = string.match(tmpstr, "%w+")
    str = str:upper()
    return str
end

local function get_qos_tfs_info()
	local tfs_info_list = {}
	local tfs_t = tfs.TFS_INST()
	local stats_tbl
	local total
	
	stats_tbl, total = tfs.TFS_INST():load_all_stats()
	
	for _, stats in ipairs(stats_tbl) do
		for k,vt in pairs(stats) do
			if k == "mac" then
				tfs_info_list[TrimStr(vt)] = stats
			end
		end
    end
	
	return tfs_info_list
end

local function get_qos_user_info()
	local user_info_list = {}
	local tmp_qos_user_info
	local user_info_list_text
	local user_info_text
	local start_idx
	local end_idx
	local i
	local j
	local down_cumu
	local down_rate
	local up_cumu
	local up_rate
	
	tmp_qos_user_info = io.popen("/tmp/tm-shn/shn_ctrl -a get_qos_user_info")
	if not tmp_qos_user_info then
		printf("tmp_qos_user_info is nil")
		return user_info_list
	end
	
	user_info_list_text = tmp_qos_user_info:read("*all")
	tmp_qos_user_info:close()
	if not user_info_list_text then
		printf("user_info_list_text is nil")
		return user_info_list
	end
	
	end_idx = string.find(user_info_list_text, "uid")
	while end_idx do
		start_idx = end_idx
		end_idx = string.find(user_info_list_text, "uid", start_idx+1)
		if end_idx then
			user_info_text = string.sub(user_info_list_text, start_idx, end_idx-1)
		else
			user_info_text = string.sub(user_info_list_text, start_idx, -1)
		end
		
		local user_info = {}
		_,_,user_info.mac = string.find(user_info_text, "mac%s*:%s*(%w%w:%w%w:%w%w:%w%w:%w%w:%w%w)")
		user_info.traffic = 0
		user_info.down_rate = 0
		user_info.up_rate = 0
		i,j,down_cumu,down_rate,up_cumu,up_rate = string.find(user_info_text, "\n%s*%d+,%d+%s*(%d+),%s*(%d+).-,%s*.-,%s*.-,%s*%d+:%d+%s*(%d+),%s*(%d+)")
		
		while i do
			user_info.traffic = user_info.traffic + down_cumu + up_cumu
			user_info.down_rate = user_info.down_rate + down_rate
			user_info.up_rate = user_info.up_rate + up_rate
			i,j,down_cumu,down_rate,up_cumu,up_rate = string.find(user_info_text, "\n%s*%d+,%d+%s*(%d+),%s*(%d+).-,%s*.-,%s*.-,%s*%d+:%d+%s*(%d+),%s*(%d+)", j+1)
			
		end
		if user_info.mac then
			user_info_list[TrimStr(user_info.mac)] = user_info
		end
		
	end
	return user_info_list
end

local function get_list( list_type )
    local list	= {}
	local uci_r = uci.cursor()
    
	uci_r:foreach("access_control", list_type,
        function(section)
            list[#list + 1] = uci_r:get_all("access_control", section[".name"])
            list[#list].mac = (list[#list].mac):gsub(":", "-"):upper()
        end
    )
    return list
end


local function get_block_client_list()	
	local uci_r       = uci.cursor()
	local enable      = uci_r:get("access_control", "settings", "enable")
	local access_mode = uci_r:get("access_control", "settings", "access_mode")
	local black_list  = get_list("black_list")
	local white_list  = get_list("white_list")
	local block_list  = {}

	if enable == "on" then
		if access_mode == "black" then
			for _, black in ipairs(black_list) do
				if black then
					block_list[TrimStr(black.mac)] = black	
				end
			end
		elseif access_mode == "white" then
			for _, white in ipairs(white_list) do
				if white then
					block_list[TrimStr(white.mac)] = white
				end
			end
		end
	end

	return block_list
end	

function QOS_INST:get_wanspeed_by_tm()
	local up_speed = 0
	local down_speed = 0
	local user_info_list = get_qos_user_info()
    
	for i, v in pairs(user_info_list) do
		up_speed = up_speed + v.up_rate
		down_speed = down_speed + v.down_rate
	end
	
	return up_speed, down_speed
end

--function get_qos_user_info
function QOS_INST:get_device_list(form)
    local priority_list = {}
    local normal_list = {}
	local tfs_info_list = {}
	
	tfs_info_list = get_qos_tfs_info()
    client_list = clientmgmt.get_access_client_list_qos()
	
    for i, v in ipairs(client_list) do
        local client = {}
        client.index = i
		-- client.key = "key-"..i
		client.key = v.mac
        client.deviceName = v.name
        client.deviceType = v.client_type
        client.deviceTag = v.wire_type
        client.mac = v.mac
		local tfs_info = tfs_info_list[TrimStr(client.mac)]
		
		if tfs_info then
			client.trafficUsage = tfs_info.total_byte
			client.uploadSpeed = tfs_info.cur_byte_tx
			client.downloadSpeed = tfs_info.cur_byte_rx
		else
			client.trafficUsage = 0
			client.uploadSpeed = 0
			client.downloadSpeed = 0
		end	
					
        client.timePeriod = v.time_period
        client.remainTime = 0
        if v.prio == "on" then
            client.enablePriority = true
            if  v.prio_time ~= -1 then
                client.remainTime = v.prio_time - os.time()
            end
        else
            client.enablePriority = false
        end

        if client.enablePriority == true then
            priority_list[#priority_list + 1] = client
        elseif v.online == 1 then
            normal_list[#normal_list + 1] = client
        end
    end
    if priority_list then
        sort_devlist(priority_list)
    end
    if normal_list then
        sort_devlist(normal_list)
    end

    for i,v in ipairs(normal_list) do
        table.insert(priority_list, v)
    end
    return priority_list
end

local function AdjustTime(old,new)
    local timeout = {}
    if new.enablePriority == true then
        if new.timePeriod ~= nil and new.timePeriod ~= "-1" and new.timePeriod ~= "Always" then
            timeout = os.time() + tonumber(new.timePeriod)*3600
        else
            timeout = -1
        end
    else
        timeout = -1
    end
    return timeout
end

function QOS_INST:update_device_info(form)
    local old = luci.json.decode(form.old)
    local new = luci.json.decode(form.new)
    local res = {}
    local devinfo = {}
    
    devinfo.mac = new.mac
    devinfo.name = new.deviceName
    devinfo.type = new.deviceType
    
    if new.enablePriority == true then 
        devinfo.prio = "on"
		devinfo.prio_time = AdjustTime(old, new)
		devinfo.time_period = new.timePeriod == "Always" and -1 or new.timePeriod
    else
        devinfo.prio = ""
		devinfo.prio_time = ""
		devinfo.time_period = ""
    end
    --_print_tbl(devinfo)
    res = clientmgmt.set_client_info(devinfo)
    if not res then
        return res, "add client to uci fail"
    end
	
	sys.fork_exec(QOS_RESTART_CMD)
    return self:get_device_list(form)
end

function QOS_INST:batch_update_device_info(form)
    local res = {}
    local devinfo = {}
    local i = 1
    
    local timestamp = AdjustTime(nil, form[1])

    for k,v in pairs(form) do
        devinfo[i] = {}
        devinfo[i].mac = v.mac
        devinfo[i].name = v.deviceName
        devinfo[i].type = v.deviceType
        
        if v.enablePriority == true then 
            devinfo[i].prio = "on"
            devinfo[i].prio_time = timestamp
            devinfo[i].time_period = v.timePeriod == "Always" and -1 or v.timePeriod
        else
            devinfo[i].prio = ""
            devinfo[i].prio_time = ""
            devinfo[i].time_period = ""
        end

        i = i + 1
    end

    --_print_tbl(devinfo)
    res = clientmgmt.batch_set_client_info(devinfo)
    if not res then
        return res, "add client to uci fail"
    end
    
    sys.fork_exec(QOS_RESTART_CMD)
    
    return self:get_device_list()
end

function QOS_INST:update_device_status()
    return clientmgmt.client_house_keeping()
end

function QOS_INST:tmp_get_mode(app_form)
    local result = {}

    result.qos_mode = self.uci:get(self.config, "qos_mode", "mode")

    if result.qos_mode == "custom" then
		local custom_detail = {}
        custom_detail.game = self.uci:get(self.config, "custom_detail", "game")
        custom_detail.media = self.uci:get(self.config, "custom_detail", "media")
        custom_detail.surf = self.uci:get(self.config, "custom_detail", "surf")
        custom_detail.chat = self.uci:get(self.config, "custom_detail", "chat")
        custom_detail.download = self.uci:get(self.config, "custom_detail", "download")
		result.custom_detail = custom_detail
    end

    local ret = {}
	ret.result = luci.json.encode(result)
	return ret
end

function QOS_INST:tmp_set_mode(app_form)
	local data = luci.json.decode(app_form.data)
	if not data and type(data) ~= "table" then
		dbg.print("invalid data")
		return {errorcode="invalid new params"}
	end
	
    local qos_mode = data.qos_mode

    self.uci:set(self.config, "qos_mode", "mode", qos_mode)
    if qos_mode == "custom" then
		local custom_detail = data.custom_detail

        if not custom_detail or not custom_detail.game or not custom_detail.media or
            not custom_detail.surf or not custom_detail.chat or not custom_detail.download then
             return false, "invalid args"
        end

        -- priority set
        self.uci:set(self.config, "custom_detail", "game", custom_detail.game)
        self.uci:set(self.config, "custom_detail", "media", custom_detail.media)
        self.uci:set(self.config, "custom_detail", "surf", custom_detail.surf)
        self.uci:set(self.config, "custom_detail", "chat", custom_detail.chat)
        self.uci:set(self.config, "custom_detail", "download", custom_detail.download)
    end

    local stat = self.uci:commit(self.config)
    if not stat then
        return false, "qos commit failed."
    end
	
	sys.fork_exec(QOS_RESTART_CMD)
	
	-- sync HNAT
	Nat:sync_hnat_status()
	
    local ret = {}
	local result = {}
	ret.result = luci.json.encode(result)
	return ret
end

function QOS_INST:tmp_get_dev_list(app_form)
	local data = luci.json.decode(app_form.data)
	if not data and type(data) ~= "table" then
		dbg.print("invalid data")
		return {errorcode="invalid new params"}
	end
	local start_index = tonumber(data.start_index)
	local amount = tonumber(data.amount)
	--[[
	local start_index = tonumber(app_form.start_index)
	local amount = tonumber(app_form.amount)
	]]--
	
	local total = 0
	local res = {}
	local result = {}
	local uci_s = uci.cursor()

	local dev_list = {}
	local client_list = clientmgmt.get_access_client_list_qos()
	local block_client_list = get_block_client_list()
	local access_mode = uci_s:get("access_control", "settings", "access_mode")
	
	local tfs_info_list = {}
	tfs_info_list = get_qos_tfs_info()

	local traffic_onoff = uci_s:get("tfstats", "switch", "enable") or "off"
    for i, v in ipairs(client_list) do
		if total >= start_index and total < start_index + amount then
			local client = {}
			client.ip = clientmgmt.get_ip_by_mac(v.mac) or "0.0.0.0"
			client.mac = v.mac
			client.name = nixio.bin.b64encode(v.name)
			client.client_type = v.client_type
			--client.conn_type = v.wire_type
			client.conn_type = getConnType(v) or "wired"
			--client.online = v.online or 0
			client.online = client.ip~="0.0.0.0" and true or false
			
			local block_client = block_client_list[TrimStr(client.mac)]
			if  access_mode == "black"	then 
				if block_client  then
					client.online  = false
				end
			elseif access_mode == "white" then 	
				if block_client  then
					client.online  = true
				end
			end
			client.access_time = v.access_time
			client.owner_id = tonumber(v.owner_id) or -1
			client.owner_name = nixio.bin.b64encode(v.owner_name) or ""
			client.remain_time = 0
			if v.prio == "on" then
				--client.enable_priority = 1
				client.enable_priority = true
				client.time_period = tonumber(v.time_period)
				if  v.prio_time ~= -1 then
					client.remain_time = v.prio_time - os.time()
				else
					client.remain_time = -1
				end
			else
				--client.enable_priority = 0
				client.enable_priority = false
				client.remain_time = -1
				client.time_period = -1
			end
			
			local user_info = tfs_info_list[TrimStr(client.mac)] 

			if traffic_onoff == "on" then
				client.traffic_usage = 0
			else
				-- No traffic usage
				-- client.traffic_usage = -1
			end

			if user_info then 
				client.traffic_usage = user_info.total_byte
			end

			dev_list[#dev_list + 1] = client
		end
		total = total + 1
    end
	
	-- check client_type and check conn_type
	--[[
	for i, v in ipairs(dev_list) do
		local tmpType = uci_s:get("client_mgmt", TrimStr(v.mac), "type") or "" 
		local tmpName = uci_s:get("client_mgmt", TrimStr(v.mac), "name") or "" 
		if tmpType ~= "" then 
			v.client_type = tmpType
		end
		if tmpName ~= "" then
			v.name = nixio.bin.b64encode(tmpName)
		end
	end
	]]--
	result.start_index = start_index
	result.amount = #dev_list
	result.sum = total
	result.client_list = dev_list
	--[[
	return result
	]]--
	
	res.result = luci.json.encode(result)
    return res
end

function QOS_INST:tmp_get_dev_speed(app_form)
	--[[
	local data = luci.json.decode(app_form.data)
	if not data and type(data) ~= "table" then
		dbg.print("invalid data")
		return {errorcode="invalid new params"}
	end
	local start_index = tonumber(data.start_index)
	local amount = tonumber(data.amount)
	]]--
	local start_index = tonumber(app_form.start_index)
	local amount = tonumber(app_form.amount)
	
	local total = 0
	local res = {}
	local result = {}
	local dev_list = {}
	local uci_s = uci.cursor()

	local traffic_onoff = uci_s:get("tfstats", "switch", "enable") or "off"
	if traffic_onoff == "off" then
		result.start_index = start_index
		result.amount = 0
		result.sum = 0
		result.client_list_speed = dev_list
		return result
	end

	local client_list = clientmgmt.get_access_client_list_qos()
	--local user_info_list = get_qos_user_info()
	local tfs_info_list = get_qos_tfs_info()

    for i, v in ipairs(client_list) do
		if total >= start_index and total < start_index + amount then
			local client = {}
			client.mac = v.mac
			
			--local user_info = user_info_list[TrimStr(client.mac)]
			local user_info = tfs_info_list[TrimStr(client.mac)]
			if user_info then
				--client.up_speed = tonumber(user_info.up_rate)
				--client.down_speed = tonumber(user_info.down_rate)
				client.up_speed = tonumber(user_info.cur_byte_tx)
				client.down_speed = tonumber(user_info.cur_byte_rx)
			else
				client.up_speed = 0
				client.down_speed = 0
			end

			dev_list[#dev_list + 1] = client
		end
		total = total + 1
    end
	
	result.start_index = start_index
	result.amount = #dev_list
	result.sum = #dev_list
	result.client_list_speed = dev_list
	
	--res.result = luci.json.encode(result)
    --return res
	return result
end

function QOS_INST:tmp_get_dev_info(app_form)
	--[[
	local data = luci.json.decode(app_form.data)
	if not data and type(data) ~= "table" then
		dbg.print("invalid data")
		return {errorcode="invalid new params"}
	end
	local client_list = clientmgmt.get_access_client_list_qos()
	local user_info_list = get_qos_user_info()
	
	result.mac = data.mac
	local user_info = user_info_list[TrimStr(data.mac)]
	]]--
	local data = app_form
	local result = {}
	local client_list = clientmgmt.get_access_client_list_qos()
	--local user_info_list = get_qos_user_info()
	local tfs_info_list = get_qos_tfs_info()
	local uci_s = uci.cursor()
	
	result.mac = app_form.mac
	--local user_info = user_info_list[TrimStr(app_form.mac)]
	local user_info = tfs_info_list[TrimStr(app_form.mac)]
	--local user_info = user_info_list[app_form.mac]

	local traffic_onoff = uci_s:get("tfstats", "switch", "enable") or "off"
	if traffic_onoff == "off" then
		result.up_speed = -1
		result.down_speed = -1
	elseif user_info then
		--result.up_speed = tonumber(user_info.up_rate)
		--result.down_speed = tonumber(user_info.down_rate)
		result.up_speed = tonumber(user_info.cur_byte_tx)
		result.down_speed = tonumber(user_info.cur_byte_rx)
	else
		result.up_speed = 0
		result.down_speed = 0
	end
	
    for i, v in ipairs(client_list) do
		if data.mac == v.mac then
			--result.ip = v.ip or "0.0.0.0"
			result.ip = clientmgmt.get_ip_by_mac(v.mac) or "0.0.0.0"
		end
    end


	return result
	--local ret = {}
	--ret.result = luci.json.encode(result)
    --return ret
end

function QOS_INST:tmp_get_qos_tfs_info()
	return get_qos_tfs_info()
end

function QOS_INST:tmp_get_TrimStr(mac)
	return TrimStr(mac)
end

