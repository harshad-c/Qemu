--[[
LuCI - config Module

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

]]--

local luci = {}
luci.sys   = require "luci.sys"
luci.util  = require "luci.util"
local fs   = require "luci.fs"
local uci  = require "luci.model.uci"
local accountmgnt = require "luci.model.accountmgnt"
local cry = require "luci.model.crypto"
local nixio = require "nixio"
local log = require("luci.model.log").Log(293)

-- local debug = require "luci.tools.debug"
local debug = {}
function debug.printf(s)
    local file = io.open("/dev/console", "w")
    file:write(tostring(s))
    file:write("\n")
    file:close()
end

local type, os, string, io, tostring, tonumber, require, pairs, ipairs, table,pcall = type, os, string, io, tostring, tonumber, require, pairs, ipairs, table,pcall

module("luci.sys.config")

local savecfglock = "/var/run/savecfg.lck"
local save_lock

local function lock(w)
    save_lock = nixio.open(savecfglock, "w", 600)
    save_lock:flock(w and "ex" or "sh")
end

local function unlock()
    save_lock:close()
    save_lock = nil
end

local function getfilenames( path, files )
    files = files or {}
    local filetable = fs.dir(path)
    --debug.printf(filetable)
    for _, entry in ipairs(filetable) do
        if entry ~= '.' and entry ~= '..' then
            local cpath = path .. '\\' .. entry
                --debug.printf(entry .. ":" .. tostring(value))
            if fs.isdirectory(cpath) then
                getfilenames(cpath,files)
            else
                table.insert(files, entry)
            end
        end
    end
    return files
end

local function get_mtd( part_name )
    local string  = require "string"

    local file    = io.input("/proc/mtd")
    while true do
        local lines = file:read("*line")
        if not lines then return nil end
        if string.match(lines, '\"' .. part_name .. '\"') then
            return string.match(lines, "mtd%d+")
        end
    end
end

local src = {"&", "<", ">"}
local dst = {"amp", "lt", "gt"}

function toEscaped(line)
        if line == nil then
                return ""
        end

        local ret = line
        for index , key in ipairs(src) do
                ret = string.gsub(ret, "(".. key .. ")", "&" .. dst[index])
        end

        return ret
end

function toOrig(line)

        local sorg = line
        local sdst = ""
        local pos
        pos = string.find(sorg,"&")
        --print("pos:" .. tostring(pos))
        while pos and pos > 0 do
                -- head
                sdst = sdst .. string.sub(sorg, 1, pos - 1)
                --print("dst:" .. sdst)
                sorg = string.sub(sorg, pos + 1 )
                --print("org:" .. sorg)
                -- escaped fit
                for index , key in ipairs(dst) do
                        xx,yy = string.find(sorg, "^" .. key)
                        if xx then
                                sorg = string.sub(sorg, yy + 1)
                                sdst = sdst .. src[index]
                                --print("org::".. sorg)
                                --print("dst::".. sdst)
                                break
                        end
                end

                pos = string.find(sorg, "&")
                --print("pos:" .. tostring(pos))
        end
        sdst = sdst .. sorg
        return sdst
end

function fileToXml(xmlpath)
    local files = getfilenames("/etc/config")
    local uci_r = uci.cursor()

    if xmlpath == nil then
        debug.printf("error xmlpath is needed")
        return
    end

	local fp    = io.open(xmlpath, "w+")

    if fp == nil then
        debug.printf("error open file failed:".. xmlpath)
        return
    end

    fp:write('<?xml version="1.0" encoding="utf-8"?>\n')
    fp:write('<config>\n')
    for _, file in pairs(files) do
        --debug.printf(file)
        local cfgs_org = uci_r:get_all(file)
        if cfgs_org then
            fp:write("<" .. toEscaped(file) .. ">\n")
            
            local cfgs = {}
            -- sort by index
            for _ , scfg in pairs(cfgs_org) do
                cfgs[scfg['.index'] + 1] = scfg
            end

            for _ , option in ipairs(cfgs) do
                --debug.printf("--" .. cfg)
                if option['.anonymous'] then
                    fp:write("<" .. toEscaped(option['.type']) .. ">\n")
                else
                    fp:write('<' .. toEscaped(option['.type']) .. ' name="' .. toEscaped(option['.name']) .. '">\n')
                end

                for key, value in pairs(option) do
                    --debug.printf("----".. tostring(key) .. " " .. tostring(value))
                    if type(value) == 'table' then
                        fp:write("<list>\n")
                        --get a list
                        for _, rule in ipairs(value) do
                            --debug.printf("------" ..rule)
                            fp:write('<' .. toEscaped(key) ..'>'.. toEscaped(rule) .. '</' .. toEscaped(key) .. '>\n')
                        end
                        fp:write("</list>\n")
                    elseif tostring(key):byte() ~= 46 then
                        fp:write("<" .. toEscaped(key) .. ">" .. toEscaped(value) .. "</" .. toEscaped(key) .. ">\n")
                    end
                end
                fp:write("</" .. toEscaped(option['.type']) .. ">\n")
            end
            fp:write("</" .. toEscaped(file) .. ">\n")
        else
            fp:write("<".. toEscaped(file) ..">\n</" .. toEscaped(file) ..">\n")
        end
    end
    fp:write('</config>')
    fp:close()
end

--temp func below
function convertFileToXml(filepath,xmlpath)
	local files = nil
	local uci_r = uci.cursor()
	
	if xmlpath == nil or filepath == nil then
		debug.printf("error xmlpath is needed")
		return
	end

	local fp    = io.open(xmlpath, "w+")

	if fp == nil then
		debug.printf("error open file failed:".. xmlpath)
		return
	end

	files = getfilenames(filepath)
	if files == nil then
		debug.printf("error get files in filepath: "..filepath)
		return
	end
	
	fp:write('<?xml version="1.0" encoding="utf-8"?>\n')
	fp:write('<config>\n')
	for _, file in pairs(files) do
		--debug.printf(file)
		
		--set the filepath for uci
		local conf_dir = uci_r:get_confdir()
		uci_r:set_confdir(filepath)
		local cfgs_org = uci_r:get_all(file)
		uci_r:set_confdir(conf_dir)
		
		if cfgs_org then
			fp:write("<" .. toEscaped(file) .. ">\n")
			
			local cfgs = {}
			-- sort by index
			for _ , scfg in pairs(cfgs_org) do
				cfgs[scfg['.index'] + 1] = scfg
			end

			for _ , option in ipairs(cfgs) do
				--debug.printf("--" .. cfg)
				if option['.anonymous'] then
					fp:write("<" .. toEscaped(option['.type']) .. ">\n")
				else
					fp:write('<' .. toEscaped(option['.type']) .. ' name="' .. toEscaped(option['.name']) .. '">\n')
				end

				for key, value in pairs(option) do
					--debug.printf("----".. tostring(key) .. " " .. tostring(value))
					if type(value) == 'table' then
						fp:write("<list>\n")
						--get a list
						for _, rule in ipairs(value) do
							--debug.printf("------" ..rule)
							fp:write('<' .. toEscaped(key) ..'>'.. toEscaped(rule) .. '</' .. toEscaped(key) .. '>\n')
						end
						fp:write("</list>\n")
					elseif tostring(key):byte() ~= 46 then
						fp:write("<" .. toEscaped(key) .. ">" .. toEscaped(value) .. "</" .. toEscaped(key) .. ">\n")
					end
				end
				fp:write("</" .. toEscaped(option['.type']) .. ">\n")
			end
			fp:write("</" .. toEscaped(file) .. ">\n")
		else
			fp:write("<".. toEscaped(file) .."/>\n")
		end
	end
	fp:write('</config>')
	fp:close()
end
--temp func above

local function getxmlkey(line)
    local keys = {'empty', 'single', 'end', 'new'}
    local exps = { '<(.+)/>', '<(.-)>(.-)</(.+)>', '</(.+)>', '<(.+)>'}
    
    line =string.gsub(line, "(')","'\\''")
    for key, exp in ipairs(exps) do
        local data = string.match(line, exps[key])
        if data then
            if keys[key] == 'single' then
                --check single entry'name
                local single1 = string.match(line, '<(.-)>.-</.+>')
                local single2 = string.match(line, '<.->.-</(.+)>')
                if single1 == single2 then
                    return {['key'] = toOrig(keys[key]), ['value'] = toOrig(string.gsub(line, '<(.-)>(.-)</(.-)>', "%1 '%2'"))}
                else
                    debug.printf('error line.' .. line)
                    return nil
                end
            else
                return {['key'] = toOrig(keys[key]), ['value']  = toOrig(data)}
            end
        end
    end
    return nil
end

function old_xmlToFile(xmlpath, filepath)
    local fp = io.open(xmlpath, 'r')
    local step = 'dir' 
    --    dir, file, config, option
    local data,filefp,dir,file,config,option

    if not (xmlpath and filepath and fp) then
        --debug.printf("xmlpath,filepath is must exist")
		return false
    end

    local stepaddentry = {
        ['dir']    = function(data, mov)
                os.execute('mkdir '.. filepath .. '/'.. data)
                dir = data
                if mov then
                    step = 'file'
                end
              end,
        ['file']= function(data, mov)
                if filefp then
                    debug.printf("error last file is still open. " .. data)
                    return 1
                else
                    if mov then
                        step = 'config'
                        file = data
                    end
                    --debug.printf("open file" .. '/tmp/' .. dir .. '/' .. file)
                    filefp = io.open(filepath .. '/' .. dir .. '/' .. file, 'w')
                    if filefp then
                        --debug.printf("filefp is ok.")
                    end
                    if mov == false and filefp then
                        filefp:close()
                        filefp = nil
                        file = nil
                    end
                end
              end,
        ['config'] = function(data, mov)
                if filefp then
                    local tdata = data
                    filefp:write('\n')
                    local name = string.match(data, 'name="(.+)"')
                    if name then
                        filefp:write('config '.. string.gsub(data, '(.+) name="(.+)"', "%1 '%2'") .. '\n')
                        tdata = string.match(data, '(.+) name=".+"')
                    else
                        filefp:write('config '.. data .. '\n')
                    end
                    if mov then
                        step = 'option'
                        if config then
                            debug.printf("error ".. config .. "config not closed. new: " .. data)
                            return 1
                        else
                            --debug.printf('set config: ' .. tdata)
                            config = tdata
                        end
                    end
                else
                    debug.printf("error:no file is open, config: " .. data)
                    return 1
                end
               end,
        ['option'] = function(data, mov)
                if filefp then
                    if mov then
                        step = 'list'
                        option = data
                    else
                        filefp:write('    option ' .. data .. '\n')
                    end
                else
                    debug.printf("error:no file is open, option: " .. data)
                    return 1
                end
               end,
        ['list']   = function(data)
                if filefp then
                    filefp:write('    list '.. data .. '\n')
                else
                    debug.printf("error:no file is open, list: " .. data)
                    return 1
                end
                 end    
    }

    local stependentry = {
        -- end is step forward
        ['dir']      = function(data)
                debug.printf("error where to go ?")
                end,
        ['file']  = function(data)
				--[[if data ~= dir then
                    debug.printf("error file end." .. data)
					return 1
				end]]--
				if data == dir then
					step = 'dir'
					dir = nil
				else
					debug.printf("error dir end." .. data)
                    return 1
                end
                end,
        ['config']= function(data)
                if data == file and filefp then
                    filefp:close()
                    filefp = nil
                    file = nil
                    step = 'file'
                else
                    debug.printf("error file end." .. data)
                    return 1
                end
                end,
        ['option']= function(data)
                if data == config and filefp then
                    step = 'config'
                    config = nil
                else
					debug.printf("error config end. " .. data .. ' != ' .. config)
                    return 1
                end
                end,
        ['list']= function(data)
                if data == option and filefp then
                    step = 'option'
                    option = nil
                else
					debug.printf("error option end." .. data)
                    return 1
                end
                end
    }

    local func = {
        ['empty'] = function(data)
                return stepaddentry[step](data, false)
              end,
        ['end']    = function(data)
                return stependentry[step](data)
              end,
        ['single']= function(data)
                return stepaddentry[step](data, false)
              end,
        ['new']    = function(data)
                return stepaddentry[step](data, true)
              end
    }
    -- drop xml head
    local tmp = 0
    local errorline = nil
	local ret = true
    
    -- do work
    for line in fp:lines() do
        --errorline in middle
        if errorline then
            debug.printf("error unkown line: " .. line)
            break
        end
        if tmp == 1 then
            --debug.printf(line)
            data = getxmlkey(line)
            if data then
                --debug.printf("key:" .. data.key .. " value:" .. data.value)
                if func[data.key](data.value) then
                    debug.printf("error operation failed: ".. line)
                    break
                end
            else
                errorline = line
            end
        end
        tmp = 1
    end
    
    --integrity check
    if filefp or file or config or option then
        debug.printf("error:config is not finish(filefp,file,config,option): " .. tostring(filefp) .. tostring(file) .. tostring(config) .. tostring(option))    
		ret = false
    end

    fp:close()
	return ret
end

function xmlToFile(xmlpath, filepath)
	local res,ret = pcall(old_xmlToFile,xmlpath,filepath)
	if res then
		return ret
	else
		debug.printf("error:xml file is bad,error info is "..tostring(ret))
		return false
	end
end

function filesize(path)
    local size = 0
    local file = io.open(path,"r")
    
    if file then
        local current = file:seek()
        size=file:seek("end")
        file:seek("set",current)
        io.close(file) 
    end
    return size
end        

function check_cfgsize(cfgFile)
		 local uci_r = uci.cursor()
		 local min_fsize = uci_r:get_profile("global","min_userconfig_size") or 0
		 local fsize = 0
		 
		 fsize = filesize(cfgFile)
		 if min_fsize ~= 0 and fsize < min_fsize then
		 		debug.printf("user-config size too small!!!" .. fsize)
		 		log(201,"user-config size too small:" .. fsize)
		 		return false
		 else
		 		return true
		 end				 
end

function local_saveconfig()  
    fileToXml("/tmp/user-config.xml")
    os.execute("tar -czf /tmp/user-config.tar /tmp/user-config.xml  >/dev/null 2>&1")
    
    -- check the total file size
    if check_cfgsize("/tmp/user-config.tar") ~= true then        
        -- try once more
        fileToXml("/tmp/user-config.xml")
        os.execute("tar -czf /tmp/user-config.tar /tmp/user-config.xml  >/dev/null 2>&1")
        if check_cfgsize("/tmp/user-config.tar") ~= true then
        		return false
        end        
		end
    
    os.execute("nvrammanager -w /tmp/user-config.tar -p  user-config   >/dev/null 2>&1")
    os.execute("rm -f /tmp/user-config.xml /tmp/user-config.cry >/dev/null 2>&1")
    -- debug.printf("saveconfig() end:")
    return true
end

function saveconfig()
    lock(true)
    local_saveconfig()
    unlock()    
end

function resetconfig()
    --os.execute("mtd erase userconf >/dev/null 2>&1; cat /dev/" .. get_mtd("defconf") .. " > /dev/".. get_mtd("userconf"))
    debug.printf("resetconfig() begin:")
    os.execute("nvrammanager -e  -p  user-config  >/dev/null 2>&1")
    os.execute("nvrammanager -r /tmp/default-config.tar -p  default-config  >/dev/null 2>&1")
	--cry.dec_file("/tmp/default-config.tar", "/tmp/default-config.cry", "0123456789abcdef    ")
	os.execute("tar -xzf /tmp/default-config.tar -C /tmp/  >/dev/null 2>&1")
	os.execute("mv /tmp/default-config.xml /tmp/user-config.xml  >/dev/null 2>&1")
	
	os.execute("tar -czf /tmp/user-config.tar /tmp/user-config.xml  >/dev/null 2>&1")
	--cry.enc_file("/tmp/user-config.cry", "/tmp/user-config.tar", "0123456789abcdef    ")
    os.execute("nvrammanager -w /tmp/user-config.tar -p  user-config   >/dev/null 2>&1")
    os.execute("rm -f /tmp/default-config.tar /tmp/user-config.tar /tmp/user-config.xml >/dev/null 2>&1")
    debug.printf("resetconfig() end:")
end

function isupgrade()
    local upgrade
    local fp = io.open("/tmp/isupgrade",'r')
    if fp == nil then
        return false
    else
        upgrade = fp:read("*a")
        fp:close()
        if upgrade:match("[.]*true[.]*") then
            return true
        else
            return false
        end
    end
    return false
end
function clear_upgrade_flag()
    os.execute("rm -f /tmp/isupgrade")
end

function reloadconfig()
    local result
    local uci_r = uci.cursor()
    
    debug.printf("reloadconfig() begin:")
    os.execute("nvrammanager  -r /tmp/user-config.tar -p  user-config  >/dev/null 2>&1")
    
    local min_fsize = uci_r:get_profile("global","min_userconfig_size") or 0
    local fsize = filesize("/tmp/user-config.tar")
    if min_fsize ~= 0 and fsize < min_fsize then
        debug.printf("user-config size too small!!!" .. fsize)
        log(201,"user-config size too small:" .. fsize)
        resetconfig()
        --try to load again
        os.execute("rm -f /tmp/user-config.xml >/dev/null 2>&1")
        os.execute("nvrammanager  -r /tmp/user-config.tar -p  user-config  >/dev/null 2>&1")        
    else
        debug.printf("user-config size OK:" ..  fsize)    
    end
    
    result = luci.sys.fork_call("tar -xzf /tmp/user-config.tar -C /  >/dev/null 2>&1")
    debug.printf("result is ")
    debug.printf(result)
    local file,err = io.open("/tmp/user-config.xml",'r')
            
    if file == nil or result ~= 0 then
        --load from defconfig
        debug.printf("no userconfig")
        log(201,"no user-config")
        resetconfig()
        --try to load again
        os.execute("rm -f /tmp/user-config.xml >/dev/null 2>&1")
        os.execute("nvrammanager  -r /tmp/user-config.tar -p  user-config  >/dev/null 2>&1")
		--cry.dec_file("/tmp/user-config.cry", "/tmp/user-config.tar", "0123456789abcdef    ")
		os.execute("tar -xzf /tmp/user-config.tar -C /  >/dev/null 2>&1")
        file,err = io.open("/tmp/user-config.xml",'r')
        if file:read(6) == '<?xml 'then
                    file:close()
                    os.execute("rm -rf /etc/config >/dev/null 2>&1")
                    xmlToFile("/tmp/user-config.xml", "/etc")
        else
            debug.printf("error no config")
        end
    elseif file:read(6) == '<?xml 'then
        file:close()
        --debug.printf("file not nil")
        os.execute("rm -rf /etc/config >/dev/null 2>&1")
        xmlToFile("/tmp/user-config.xml", "/etc")
	else
        --debug.printf("file open err")
		file:close()
		print(err)
    end

	os.execute("rm -f /tmp/user-config.cry /tmp/user-config.tar /tmp/user-config.xml >/dev/null 2>&1")
    
    debug.printf("reloadconfig() end:")
    
	merge_config_by_country()
	merge_mfconfig()
end

function getsysinfo(option)

    local fp,err
    local  softVerOption = "soft_ver"
    
    if option == "SOFTVERSION" then    
        --debug.printf("zlw debug :  SOFTVERSION")
        os.execute("nvrammanager  -r /tmp/softversion -p  soft-version  >/dev/null 2>&1")
        fp,err = io.open("/tmp/softversion",'r')
        
        if fp == nil then
            debug.printf(err)
        else
            local value
            for line in fp:lines() do
                value = string.match(line, string.format("%s:(.+)", softVerOption))
                --debug.printf(line)
                --debug.printf(value)
                if value then
                    fp:close()
                    return value
                end
            end
            fp:close()
        end
    end
    
    if option == "HARDVERSION" then
        --debug.printf("zlw debug :  HARDVERSION")
        local  aliasForVerOption = "product_ver"
        local  productNameOption = "product_name"
        local  product_name
        local  product_ver
        --debug.printf("zlw debug :  " .. aliasForOption)
        os.execute("nvrammanager  -r /tmp/productinfo -p  product-info  >/dev/null 2>&1")
        fp,err = io.open("/tmp/productinfo",'r')
        
        if fp == nil then
            debug.printf(err)
        else
            local value1, value2
            for line in fp:lines() do
                value1 = string.match(line, string.format("%s:(.+)", productNameOption))
                value2 = string.match(line, string.format("%s:(.+)", aliasForVerOption))
                --debug.printf(value1)
                --debug.printf(value2)
                if value1 then
                    product_name = value1
                    --debug.printf(product_name)
                end
                if value2  then
                    if string.len(value2) == 5 then 
                        product_ver = string.sub(value2, 1, -3)
                    else 
                        product_ver = value2
                    end
                    --debug.printf(product_ver)
                end
                if product_name and product_ver  then
                    --debug.printf(product_name .. " v" .. product_ver)
                    fp:close()
                    return (product_name .. " v" .. product_ver)
                end
            end
            fp:close()
        end
    end
    
    if option == "PIN" then
        --debug.printf("zlw debug :  PIN")
        os.execute("nvrammanager  -r /tmp/pin -p  pin  >/dev/null 2>&1")    
        fp,err = io.open("/tmp/pin",'r')
        
        if fp == nil then
            debug.printf(err)
        else
            local value
            for line in fp:lines() do
                --value = string.match(line, string.format("%s:(.+)", option))
                value = line
                --debug.printf(line)
                --debug.printf(value)
                if value then
                    fp:close()
                    return value
                end
            end
            fp:close()
        end
    end

    if option == "device_name" then
		--- we use porduct_name to represent device_name, because usually it is the same.
        os.execute("nvrammanager  -r /tmp/productinfo -p  product-info  >/dev/null 2>&1")
        fp,err = io.open("/tmp/productinfo",'r')
        
        if fp == nil then
            debug.printf(err)
        else
            local value
            for line in fp:lines() do
                value = string.match(line, string.format("%s:(.+)", "product_name"))
                if value then
                    fp:close()
                    return value
                end
            end
            fp:close()
        end

    end
    
    if option then
        --debug.printf("zlw debug :  option")
        os.execute("nvrammanager  -r /tmp/productinfo -p  product-info  >/dev/null 2>&1")
        fp,err = io.open("/tmp/productinfo",'r')
        
        if fp == nil then
            debug.printf(err)
        else
            local value
            for line in fp:lines() do
                value = string.match(line, string.format("%s:(.+)", option))
                if value then
                    fp:close()
                    return value
                end
            end
            fp:close()
        end

    end
    
    return nil

end

function reload_profile()
    
    debug.printf("reload_profile() begin:")
    os.execute("nvrammanager -r /tmp/reload-profile.xml -p  profile   >/dev/null 2>&1")
        
    local file,err = io.open("/tmp/reload-profile.xml",'r')

    if file == nil then
        debug.printf(err)

    elseif file:read(6) == '<?xml 'then
        file:close()
        os.execute("rm -rf /etc/profile.d >/dev/null 2>&1")
        xmlToFile("/tmp/reload-profile.xml", "/etc")
        os.execute("chmod -R 444 /etc/profile.d >/dev/null 2>&1")

    else
        file:close()
        debug.printf("error no profile")
    end
    
    os.execute("rm -f /tmp/reload-profile.xml >/dev/null 2>&1")
    debug.printf("reload_profile() end:")
end

function get_config(line, filename)
    local ret
    local uci_r = uci.cursor()
    if type(line) ~= "string" then return nil end
    head = line:sub(1,6)
    if head ~= "config" then return nil end
    local config_pos = string.find(line, "\'")
    if config_pos == nil then
        cfg_name = string.sub(line, 8, -1)
        ret = uci_r:get_first(filename, cfg_name, nil, nil)
    else
        ret = string.sub(line, config_pos+1, -2)
    end
    return ret
end

function get_option(line)
    local opt_name, opt_value, i, j
    if type(line) ~= "string" then return nil, nil end
    i, j = string.find(line, "option")
    if i == nil or j == nil then return nil, nil end
    local opt_pos = string.find(line, "\'")
    opt_name = string.sub(line, j+2, opt_pos-2)
    opt_value = string.sub(line , opt_pos+1, -2)
    return opt_name, opt_value
end

function merge_country_config(country)
	local uci_r = uci.cursor()
    local cmd = "ls /tmp/merge/"..country
    local s = io.popen(cmd)
    local fileLists = s:read("*all")
    local start_pos = 0
    local end_pos = 0
    while true do
        end_pos = string.find(fileLists, "\n", start_pos)
        if end_pos == nil then break end
        local filename = string.sub(fileLists, start_pos, end_pos-1)
        local file, err  = io.open("/tmp/merge/" ..country.."/".. filename, "r")
        if file == nil then debug.printf(err) end
        for line in file:lines() do
            if line:sub(1,6) == "config" then
                config_name = get_config(line, filename)
            elseif line ~= "nil" then
                option_name, option_value = get_option(line)
                if config_name ~= nil and option_name ~= nil and option_value ~= nil then
                    uci_r:set(filename, config_name, option_name, option_value)
                end
            end
        end
        uci_r:commit(filename)
        io.close(file)

        start_pos = end_pos + 1
    end
end

function set_SSID(form)
    local sys = require "luci.sys"
    local uci_r = uci.cursor()
    local cmd = "network_get_firm ".. form
    local wan_mac = sys.exec(cmd)
    wan_mac = wan_mac:upper()
    local mac5,mac6=wan_mac:match('(..)-(..)%c$')
    local suffix = mac5 .. mac6
    local wlan = require "luci.model.wireless"
    local ap = wlan.Apcfg("wps_pin", {"wps_label", "wps_pin"})
    local driver = ap:scan_driver()
    
    local wireless_iface = {}
    wireless_iface.hst2g = driver[2][1]
    wireless_iface.hst5g = driver[3][1]
    wireless_iface.gst2g = driver[5][1]
    wireless_iface.gst5g = driver[7][1]
    
    local support_triband = uci_r:get_profile("wireless","support_triband") or "no"
    if support_triband == "yes" then
        wireless_iface.hst52_g = driver[31][1]
        wireless_iface.gst52_g = driver[37][1]
    end
    
    local hst_prefix = "TP-LINK_"
    local gst_prefix = "TP-LINK_GUEST_"
    local suffix_5g  = "_5G"
    local suffix_52_g  = "_52G"
    
    for k, v in pairs(wireless_iface) do
        local ssid
        if k:find("hst") ~= nil then
            if k:find("52_g") ~= nil then
                ssid = hst_prefix .. suffix .. suffix_52_g
            elseif k:find("5g") ~= nil then
                ssid = hst_prefix .. suffix .. suffix_5g
            else
                ssid = hst_prefix .. suffix
            end
        else
            if k:find("52_g") ~= nil then
                ssid = gst_prefix .. suffix .. suffix_52_g
            elseif k:find("5g") ~= nil then
                ssid = gst_prefix .. suffix .. suffix_5g
            else
                ssid = gst_prefix .. suffix
            end
        end
        uci_r:set("wireless", v, "ssid", ssid)
    end
    uci_r:commit("wireless")
end
    
function get_default_config(country)
	local uci_r = uci.cursor()
    local cmd = "ls /tmp/merge/"..country
    local s = io.popen(cmd)
    local fileLists = s:read("*all")
    local start_pos = 0
    local end_pos = 0
    local default_config = {}
    while true do
        end_pos = string.find(fileLists, "\n", start_pos)
        if end_pos == nil then break end
        local filename = string.sub(fileLists, start_pos, end_pos-1)
        local file, err  = io.open("/tmp/merge/" ..country.."/".. filename, "r")
        if file == nil then debug.printf(err) end
        default_config[filename]={}
        for line in file:lines() do
            if line:sub(1,6) == "config" then
                config_name = get_config(line, filename)
                default_config[filename][config_name]={}
            elseif line ~= "nil" then
                option_name, option_value = get_option(line)
                if config_name ~= nil and option_name ~= nil and option_value ~= nil then
                    default_config[filename][config_name][option_name]=option_value
                end
            end
        end
        io.close(file)

        start_pos = end_pos + 1
    end
    return default_config
end

function revert_country_config(country)
	local uci_r = uci.cursor()
    local cmd = "ls /tmp/merge/"..country
    local s = io.popen(cmd)
    local fileLists = s:read("*all")
    local start_pos = 0
    local end_pos = 0
    local default_config = {}
    default_config = get_default_config("UN")
    while true do
        end_pos = string.find(fileLists, "\n", start_pos)
        if end_pos == nil then break end
        local filename = string.sub(fileLists, start_pos, end_pos-1)
        local file, err  = io.open("/tmp/merge/" ..country.."/".. filename, "r")
        if file == nil then debug.printf(err) end
        for line in file:lines() do
            if line:sub(1,6) == "config" then
                config_name = get_config(line, filename)
            elseif line ~= "nil" then
                option_name, option_value = get_option(line)
                if config_name ~= nil and option_name ~= nil and option_value ~= nil then
                    uci_r:set(filename, config_name, option_name, default_config[filename][config_name][option_name])
                end
            end
        end
        io.close(file)

        start_pos = end_pos + 1
    end
    return default_config
end

function merge_config_by_country(old_country)
	debug.printf("mergeconfigbycountry() begin")
	local uci_r = uci.cursor()
    local country = uci_r:get("locale","sysinfo","country")
    if country == nil then
        country = getsysinfo("country")
        if country == nil then 
            debug.printf("no country in productinfo")
            debug.printf("mergeconfigbycountry() do nothing end")
            return
        end
    elseif old_country == nil then
        debug.printf("user has set country")
        debug.printf("mergeconfigbycountry() do nothing end")
        return
    end
	os.execute("mkdir /tmp/merge >/dev/null 2>&1")
    os.execute("nvrammanager -r /tmp/default-config.tar -p  default-config  >/dev/null 2>&1")
	os.execute("tar -xzf /tmp/default-config.tar -C /tmp/  >/dev/null 2>&1")
    local file,err = io.open("/tmp/default-config.xml",'r')
	if file == nil then
		debug.printf(err)
	elseif file:read(6) == '<?xml 'then
		file:close()
		os.execute("rm -rf /tmp/merge/* >/dev/null 2>&1")
		local ret = xmlToFile("/tmp/default-config.xml", "/tmp/merge")
    end
    if old_country ~= "no_country" and old_country ~= nil then
        revert_country_config(old_country)
    end
    merge_country_config(country)
	os.execute("rm -rf /tmp/merge >/dev/null 2>&1")
    if country == "PL" then
        set_SSID("wan")
    end
	debug.printf("mergeconfigbycountry() end")
end

function get_mf_wifi_channel(seed)
    local math = require "math"
    local data = {}
    local tmp = 0

    if not seed then
        return nil
    end
    
    debug.printf("get_mf_wifi_channel:seed:" .. seed)
	
    local file = io.open("/dev/urandom", "rb")
    if file then
        local d = file:read(4)
        for i = 1, 4 do
            tmp = tmp * 256 + string.byte(d, i)
        end
        seed = seed + tmp % 10000000
        file:close()
    end

    math.randomseed(seed % 100000000)
	
    data.m2g = math.random(2, 10)
    data.m5g = math.random(9, 12)*4
	
	  debug.printf("2g channel:" .. data.m2g)
	  debug.printf("5g channel:" .. data.m5g)

	  return data
end

function get_pin()
    local pin = luci.util.execl("getfirm PIN")
    if pin then
        return pin[1]
    else
        return nil
    end
end

-- manufactory mode: if the channel==none,randomlize the channel,to avoid interfere
function merge_mfconfig()
    local uci_r = uci.cursor()
    local pin
    local factorymode

    factorymode = uci_r:get("factory","factorymode","enable")
    if factorymode ~= "yes" then
      -- kill tddp unless it's in manufactory mode!!!
      -- as it may cause inconvinient for factory procudue,remove this.liuqu 20171101.
      -- luci.sys.fork_call("rm -f /etc/rc.d/S*tddp")
    	return
    end
    
    pin = get_pin()
    debug.printf("pin:" .. pin)
    debug.printf("set MF channel")
    
    if pin == nil then
       pin = "03717660"
    end
    
    local data = get_mf_wifi_channel(tonumber(pin))
    if data then
        if data.m2g then
            uci_r:set("wireless", "wifi0", "channel", data.m2g)            
        end
        if data.m5g then
            uci_r:set("wireless", "wifi1", "channel", data.m5g)            
        end
        
        -- we can't commit to flash,becasue it will overwrite channel.
        -- we still need channel=none to use mac/pin tool.
        uci_r:commit_without_write_flash("wireless")           
    end
end
