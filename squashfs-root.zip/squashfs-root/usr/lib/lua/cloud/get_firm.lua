local uci = require "luci.model.uci"

local uci_r = uci.cursor()

local function TrimStr(str)
    local tmpstr = str
	
    if tmpstr == nil then
        str = ""
    else
        tmpstr = string.gsub(tmpstr, "-", "")
        str = string.match(tmpstr, "%w+")
        if str == nil then
            str = ""
        else
            str = str:upper()
        end
    end
	
    return str
end
 
function run()
    local sys = require "luci.sys"
    local accountmgnt = require "luci.model.accountmgnt"
    local cloud = require "cloud_req.cloud_comm"
    local tbl = {}
    local devInfo = {}
    local alias = uci_r:get("cloud_config", "info", "alias") or ""

	if uci_r:get("cloud_config", "info", "alias_changed") == 'false' then
		alias = string.gsub(sys.exec("getfirm HOSTNAME_UNDERLINE"), "%c", "")
	else
		alias = uci_r:get("cloud_config", "info", "alias") or ""
	end

    devInfo.deviceMac = TrimStr(sys.exec("getfirm MAC"))                 
    devInfo.deviceId = TrimStr(sys.exec("getfirm DEV_ID"))
    devInfo.hwId = TrimStr(sys.exec("getfirm HW_ID"))
    devInfo.fwId = TrimStr(sys.exec("getfirm FW_ID"))
    devInfo.deviceName = string.gsub(sys.exec("getfirm MODEL"), "%c", "")
    local tmpInfo = cloud.get_device_model_ver()
    devInfo.deviceModel = tmpInfo.device_model
    devInfo.deviceHwVer = tmpInfo.hard_ver
    devInfo.fwVer = string.gsub(sys.exec("getfirm SOFTVERSION"), "%c", "")
    devInfo.alias = alias
    devInfo.tcspVer = "1.1"
    devInfo.cloudUserName = accountmgnt.get_last_cloud_account() or "" 
    devInfo.oemId = TrimStr(sys.exec("getfirm OEM_ID"))
    
    tbl.method = "helloCloud"
    tbl.params = devInfo
    return tbl
end
